var results;
window.onload = function(){

  try {
  var xhttp = new XMLHttpRequest();
  }
  catch(e) {
  	console.log("Error creating request: ",e);
  }

  if (xhttp != null)
  {
    xhttp.addEventListener('readystatechange', function(){
      if (this.readyState == 4 && this.status == 200)
      {

        var resp = xhttp.responseXML;
        console.log(resp);
        populateDropdown(resp);
      }
    });

    xhttp.open('GET', 'https://randomuser.me/api/?format=xml&results=10');
    xhttp.send();
  }

  function populateDropdown(resp)
  {
    var users = resp.getElementsByTagName('user');
    results = resp.firstChild.getElementsByTagName('results');
    //console.log(results);
    var staffsel = document.getElementById("staffsel");
    for(var i = 0; i < results.length; i++)
    {
      var name = results[i].getElementsByTagName('name');
      if (i < results.length - 1)
      {
        var name = getName(name)
        var newOpt = document.createElement("option");
  		  newOpt.value = i;
  		  newOpt.text = name;
  		  staffsel.add(newOpt);
      }




    }
    staffsel.addEventListener('change', function(e){

      var index = staffsel.selectedIndex;
      if (index != 0)
      {
        let genderRes = results[index - 1].getElementsByTagName('gender');
        let gender = (genderRes[0].innerHTML);

        let nameRes = results[index - 1].getElementsByTagName('name');
        let title = (nameRes[0].getElementsByTagName('title')[0].innerHTML);
        title = title.charAt(0).toUpperCase() + title.slice(1);

        let first = (nameRes[0].getElementsByTagName('first')[0].innerHTML);
        first = first.charAt(0).toUpperCase() + first.slice(1);

        let last = (nameRes[0].getElementsByTagName('last')[0].innerHTML);
        last = last.charAt(0).toUpperCase() + last.slice(1);

        let emailRes = results[index - 1].getElementsByTagName('email');
        let email = (emailRes[0].innerHTML);

        let userRes = results[index - 1].getElementsByTagName('username');
        let user = (userRes[0].innerHTML);

        let dobRes = results[index - 1].getElementsByTagName('dob');
        let dob = (dobRes[0].innerHTML);

        let cellRes = results[index - 1].getElementsByTagName('cell');
        let cell = (cellRes[0].innerHTML);

        let pictureRes = results[index - 1].getElementsByTagName('picture');
        let pic = (pictureRes[0].getElementsByTagName('large')[0].innerHTML);

        var theDiv = document.getElementById('staffdisplay');
        theDiv.innerHTML = "<p class='theName'>" + title + ". " + first + " " + last + "</p><hr>";
        theDiv.innerHTML += "<p class='email'><span>Email: &nbsp;<span>" + email + "</p>";
        theDiv.innerHTML += "<p class='user'><span>User: &nbsp;<span>" + user+ "</p>";
        theDiv.innerHTML += "<p class='cell'><span>Cell: &nbsp;<span>" + cell + "</p>";
        theDiv.innerHTML += "<p class='dob'><span>DOB: &nbsp;<span>" + dob + "</p>";
        theDiv.innerHTML += "<img src='" + pic + "' alt='Profile Pic'>";
      }


    })
  }

  function getName(name)
  {
    var first = (name[0].getElementsByTagName('first')[0].innerHTML);
    first = first.charAt(0).toUpperCase() + first.slice(1);
    var last = (name[0].getElementsByTagName('last')[0].innerHTML);
    last = last.charAt(0).toUpperCase() + last.slice(1);
    //console.log(name[name.length - 1].innerHTML);
    var name = last + ", " + first;
    return name;
  }








}
