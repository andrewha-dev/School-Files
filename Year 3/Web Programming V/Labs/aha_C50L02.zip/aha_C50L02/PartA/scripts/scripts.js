try {
var xhttp = new XMLHttpRequest();
}
catch(e) {
	console.log("Error creating request: ",e);
}

if (xhttp != null)
{
  xhttp.addEventListener('readystatechange', function(){
    if (this.readyState == 4 && this.status == 200)
    {
      var responseXML = xhttp.responseXML;
      displayResult(responseXML);
      
    }
  });

  xhttp.open('GET', './movies.xml');
  xhttp.send();
}

function createTitle(title)
{
  var res = "<div class='container'>";
  for(let i = 0; i < title.length; i++)
  {
    res += "<h1>" + title[i].firstChild.data + "</h1>"

  }
  //document.getElementById('results').innerHTML += res;
  return res;
}

function createGenre(genre)
{
 var res = "";
 for (var i = 0; i < genre.length; i++)
 {
   res += "<p class='genre'><span class='lblGenre'>Genre:&nbsp;</span>" + genre[i].firstChild.data + "</p>";
 }
    //document.getElementById('results').innerHTML += res;
    return res;
}

function createYear(year)
{
  var res = "";
  for (var i = 0; i < year.length; i++)
  {
    res += "<p class='year'><span class='lblYear'>Year:&nbsp;</span>" + year[i].innerHTML.toString()+ "</p>";

  }
        //document.getElementById('results').innerHTML += res;
        return res;
}

function createDirector(director)
{
  var res = "<p class='director'><span class='lblDir'>Directors: &nbsp;</span>";
  for (var i = 0; i < director.length; i++)
  {
    res +=  director[i].innerHTML.toString();
    if (i < director.length - 1)
    res += ", ";
  }
  res += "</p>";
      //document.getElementById('results').innerHTML += res;
      return res;
}

function createCountry(country)
{
  var res = "";
  for (var i = 0; i < country.length; i++)
  {
    res += "<p class='country'><span class='lblCountry'>Country:&nbsp;</span>" + country[i].innerHTML.toString()+ "</p>";


  }
    res += "</div><br>";
      //document.getElementById('results').innerHTML += res;
      return res;
}

function displayResult(_res)
{
  var books = _res.getElementsByTagName('movie');

  // books.forEach(function(book){
  //   console.log(book);
  // });
  var res = "";
  for(let i = 0; i < books.length; i++)
  {

    let title = books[i].getElementsByTagName('title');
    res += createTitle(title);
    let genre = books[i].getElementsByTagName('genre')
     res += createGenre(genre)
    let year = books[i].getElementsByTagName('year');
     res += createYear(year);
    let director = books[i].getElementsByTagName('director');
     res += createDirector(director);
    let country = books[i].getElementsByTagName('country');
    res += createCountry(country);

  }
      //console.log(res);
      document.getElementById('results').innerHTML += res;
}

function displayResultGenre(_res)
{
  var books = _res.getElementsByTagName('movie');

  // books.forEach(function(book){
  //   console.log(book);
  // });
  var res = "";
  for(let i = 0; i < books.length; i++)
  {

    let title = books[i].getElementsByTagName('title');
    res += createTitle(title);
    let genre = books[i].getElementsByTagName('genre')
     res += createGenre(genre)
    let year = books[i].getElementsByTagName('year');
     res += createYear(year);
    let director = books[i].getElementsByTagName('director');
     res += createDirector(director);
    let country = books[i].getElementsByTagName('country');
    res += createCountry(country);

  }
      //console.log(res);
      document.getElementById('results').innerHTML += res;
}
