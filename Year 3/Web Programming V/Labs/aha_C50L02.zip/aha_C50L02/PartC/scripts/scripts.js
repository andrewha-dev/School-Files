window.onload = function(){
	fetch('./movies.json', {
		method: 'get'
	}).then(response => {
		return response.json();
	}).then(text => {
		var movies = text.movies.movie;
		var res = "<div class='container'>";
		for (var i = 0; i < movies.length - 1; i++)
		{

			let title = movies[i].title;
			let genre = movies[i].genre;
			let year = movies[i].year;
			let director = movies[i].director;
			let country= movies[i].country;

			res += "<h1>"+ title +"</h1>"
			res += "<p class='genre'><span class='lblGenre'>Genre:&nbsp;</span>" + genre + "</p>";
			res += "<p class='year'><span class='lblGenre'>Year:&nbsp;</span>" + year + "</p>";

			res += "<p class='director'><span class='lblDir'>Directors: &nbsp;</span>";
			if (Array.isArray(director))
			{
				for (var j = 0; j < director.length; j++)
				{
					res += director[j];
					if (j < director.length - 1)
					{
						res += ", ";
					}
				}
			}
			else {
				res += director;
			}

			res += "</p>";

			res += "<p class='country'><span class='lblCountry'>Country:&nbsp;</span>" + country + "</p>";


		}
		res += "</div>";
		res += "</br>";
		document.getElementById('results').innerHTML += res;

	}).catch(error => {
		console.log("Request Failed: " +  error);
	})



}
