﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace aha_L01_PartC
{
    public partial class Form : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            ValidMessage.InnerText = "Hello " + txtFirstName.Text
                + ". You are currently " + txtAge.Text + " years old. You will turn 100 in " 
                + (100 - Convert.ToInt16(txtAge.Text)) + 
                " years. I will email this report to " + txtEmail.Text + ".";
        }
    }
}