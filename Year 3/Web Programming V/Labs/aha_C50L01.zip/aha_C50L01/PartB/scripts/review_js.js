var el = document.getElementById('theForm');
el.addEventListener('submit', function(e){
  var validated = true;
  var msg = "Please fill out the following fields:</br>";
  if (firstName.value == "")
  {
    msg += "First Name is missing</br>";
    validated = false;
  }

  if (myAge.value == ""){
  msg += "Age is missing</br>";
  validated = false;
  }
  if (emailAddr.value == ""){
  msg += "Email Address is missing</br>";
  validated = false;
  }
  if (validated == false)
  {
    errorList.innerHTML = msg;
    theForm.style.backgroundColor = "grey";
    e.preventDefault();
  }

})
