package l08.aha.ca.aha_b51l08;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static android.content.Context.MODE_PRIVATE;

/**
 * A placeholder fragment containing a simple view.
 */
public class TaxCalculatorFragment extends Fragment {
    double pst = 0.0;
    double gst = 0.0;
    double hst = 0.0;
    double total = 0.0;
    double amountEntered = 0.0;boolean isLandScape = false;
    public TaxCalculatorFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View current = inflater.inflate(R.layout.fragment_tax_calculator, container, false);

        int orientation = this.getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            //code for portrait mode
            Bundle extras = getActivity().getIntent().getExtras();
            if (extras != null)
            {
                pst = extras.getDouble("PST");
                gst = extras.getDouble("GST");
                hst = extras.getDouble("HST");
                isLandScape = false;
            }

        } else {
            //code for landscape mode
            SharedPreferences prefs = getActivity().getSharedPreferences("MyPrefs", MODE_PRIVATE);
            hst = (double) prefs.getFloat("total", 0.0f);
            isLandScape = true;
        }





        EditText input = (EditText) current.findViewById(R.id.txtAmount);
        Button calc = (Button) current.findViewById(R.id.btnCalc);



        calc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isLandScape)
                {
                    SharedPreferences prefs = getActivity().getSharedPreferences("MyPrefs", MODE_PRIVATE);
                    hst = (double) prefs.getFloat("total", 0.0f);
                    EditText input = (EditText) current.findViewById(R.id.txtAmount);
                    if (!input.getText().toString().equals(""))
                    {
                        amountEntered = Double.parseDouble(input.getText().toString());
                        total = amountEntered + (amountEntered * pst) +
                                (amountEntered * gst) + (amountEntered * hst);
                        TextView res = (TextView) current.findViewById(R.id.lblResult);
                        total = Math.round(total * 100);
                        total = total/100;
                        res.setText("$" + String.valueOf(total));
                    }

                }
                else
                {
                    EditText input = (EditText) current.findViewById(R.id.txtAmount);
                    if (!input.getText().toString().equals(""))
                    {
                        amountEntered = Double.parseDouble(input.getText().toString());
                        total = amountEntered + (amountEntered * pst) +
                                (amountEntered * gst) + (amountEntered * hst);
                        TextView res = (TextView) current.findViewById(R.id.lblResult);
                        total = Math.round(total * 100);
                        total = total/100;
                        res.setText("$" + String.valueOf(total));
                    }

                }


            }
        });

        return current;

    }


}
