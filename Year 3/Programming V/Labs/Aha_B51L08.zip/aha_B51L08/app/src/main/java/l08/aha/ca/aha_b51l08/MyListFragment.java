package l08.aha.ca.aha_b51l08;

import android.app.Fragment;
import android.app.ListFragment;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by 1435792 on 11/6/2017.
 */

public class MyListFragment extends ListFragment implements AdapterView.OnItemClickListener {
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_fragment, container, false);
        return view;
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ArrayAdapter adapter = ArrayAdapter.createFromResource(getActivity(),
                R.array.provinces, android.R.layout.simple_list_item_1);
        setListAdapter(adapter);
        getListView().setOnItemClickListener(this);
    }

    public void onItemClick(AdapterView<?> parent, View view, int position,long id) {
        int orientation = this.getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            //code for portrait mode
            OpenActivity(position);
        } else {
            //code for landscape mode
            setBundle(position);
        }

    }

    public void OpenActivity(int id)
    {

        double PST = 0.0;
        double GST = 0.0;
        double HST = 0.0;

        switch (id)
        {
            case 0:
                GST = 0.05;
                break;
            case 1:
                PST = 0.07;
                GST = 0.05;
                break;
            case 2:
                PST = 0.08;
                GST = 0.05;
                break;
            case 3:
                HST = 0.15;
                break;
            case 4:
                HST = 0.15;
                break;
            case 5:
                HST = 0.15;
                break;
            case 6:
                HST = 0.13;
                break;
            case 7:
                HST = 0.15;
                break;
            case 8:
                PST = 0.0975;
                GST = 0.05;
                break;
            case 9:
                PST = 0.05;
                GST = 0.05;
                break;
            default:
                break;
        }

        Intent i = new Intent(getActivity(), TaxCalculator.class);
        i.putExtra("PST", PST);
        i.putExtra("GST", GST);
        i.putExtra("HST", HST);


        startActivity(i);

    }

    public void setBundle(int id)
    {
        double PST = 0.0;
        double GST = 0.0;
        double HST = 0.0;

        switch (id)
        {
            case 0:
                GST = 0.05;
                break;
            case 1:
                PST = 0.07;
                GST = 0.05;
                break;
            case 2:
                PST = 0.08;
                GST = 0.05;
                break;
            case 3:
                HST = 0.15;
                break;
            case 4:
                HST = 0.15;
                break;
            case 5:
                HST = 0.15;
                break;
            case 6:
                HST = 0.13;
                break;
            case 7:
                HST = 0.15;
                break;
            case 8:
                PST = 0.0975;
                GST = 0.05;
                break;
            case 9:
                PST = 0.05;
                GST = 0.05;
                break;
            default:
                break;
        }

//        SharedPreferences prefs = getActivity().getSharedPreferences("MyPrefs", MODE_PRIVATE);
//        prefs.
        SharedPreferences.Editor editor = getActivity().getSharedPreferences("MyPrefs",MODE_PRIVATE).edit();
        float total = (float)(PST + GST + HST);
        editor.putFloat("total", total);
        editor.commit();
    }

}
