package l07.aha.ca.ahab51_l07;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class showInformation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_information);
        TableLayout res = (TableLayout) findViewById(R.id.res);

        try {

            FileInputStream fin = getApplicationContext().openFileInput("updates.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(fin));
            int i = 0;
            String line = "";
            while((line = reader.readLine()) != null){
                i++;
                TableRow entry = new TableRow(this);
                TableLayout entryLayout = new TableLayout(this);
                TextView lblYear = new TextView(this);
                lblYear.setText(line.split("~")[0]);
                TextView lblInterestCell = new TextView(this);
                TextView deptNum = new TextView(this);

                TextView lblTotal = new TextView(this);

                lblTotal.setText(line.split("~")[1]);

                lblInterestCell.setText(line.split("~")[2]);

                deptNum.setText(line.split("~")[3]);

                lblYear.setTextSize(18);
                entry.addView(lblYear);
                lblTotal.setTextSize(18);
                entry.addView(lblTotal);
                lblInterestCell.setTextSize(18);
                entry.addView(lblInterestCell);
                deptNum.setTextSize(18);
                entry.addView(deptNum);

                entry.addView(entryLayout);
                res.addView(entry);

            }

        }

        catch (Exception e)
        {
            e.printStackTrace();
        }


    }
}
