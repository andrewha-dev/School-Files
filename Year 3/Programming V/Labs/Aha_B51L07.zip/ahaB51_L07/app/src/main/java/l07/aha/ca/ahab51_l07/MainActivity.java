package l07.aha.ca.ahab51_l07;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import static l07.aha.ca.ahab51_l07.R.array.StringList;

public class MainActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        ListAdapter adapter = createAdapter();
        setListAdapter(adapter);

    }

    protected ListAdapter createAdapter()
    {
        final String[] Strings = getResources().getStringArray(StringList);

        ListAdapter adapter = new ArrayAdapter<String>(this, R.layout.list_activity, R.id.txtView, Strings);
        return adapter;

    }

    protected void onListItemClick (ListView l, View v, int position, long id) {
        final String[] Strings = getResources().getStringArray(StringList);
        if (position == 0)
        {
            Intent i = new Intent(MainActivity.this, getInformation_NEW.class);
            startActivity(i);
        }

        if (position == 1)
        {
            Intent i = new Intent(MainActivity.this, showInformation.class);
            startActivity(i);
        }

        if (position == 2)
        {
            Intent i = new Intent(MainActivity.this, about.class);
            startActivity(i);
        }





    }


}
