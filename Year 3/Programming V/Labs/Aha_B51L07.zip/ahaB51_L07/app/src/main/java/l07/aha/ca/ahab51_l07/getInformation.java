package l07.aha.ca.ahab51_l07;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;

public class getInformation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_information);



        Button btnSave = (Button) findViewById(R.id.btnSave);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView firstName = (TextView) findViewById(R.id.txtFirstName);
                TextView lastName = (TextView) findViewById(R.id.txtLastName);
                TextView email = (TextView) findViewById(R.id.txtLastName);
                TextView dept = (TextView) findViewById(R.id.txtDept);

                String values = firstName.getText().toString() + "~" + lastName.getText().toString() + "~" + email.getText().toString() + "~" + dept.getText().toString() + "\n";

                try {
                    FileOutputStream fOut = getApplicationContext().openFileOutput("updates.txt", MODE_APPEND);
                    fOut.write(values.getBytes());
                    fOut.close();
                    Toast.makeText(getBaseContext(), "File Saved", Toast.LENGTH_SHORT).show();
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        });


    }
}
