package l07.aha.ca.ahab51_l07;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

public class getInformation_NEW extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_information__new);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Button btnSave = (Button) findViewById(R.id.btnSave);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView firstName = (TextView) findViewById(R.id.txtFirstName);
                TextView lastName = (TextView) findViewById(R.id.txtLastName);
                TextView email = (TextView) findViewById(R.id.txtLastName);
                TextView dept = (TextView) findViewById(R.id.txtDept);


                try {
                    FileOutputStream fOut = getApplicationContext().openFileOutput("updates.txt", MODE_APPEND);
                    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fOut));
                    String values = firstName.getText().toString() + "~" + lastName.getText().toString() + "~" + email.getText().toString() + "~" + dept.getText().toString();
                    writer.write(values);
                    writer.newLine();
                    writer.flush();
                    writer.close();
                    Toast.makeText(getBaseContext(),"File Saved", Toast.LENGTH_SHORT).show();

                }
                catch (Exception e){
                    System.out.println("Broke");
                    e.printStackTrace();
                }
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id =  item.getItemId();
        if (id == R.id.preferences)
        {
            Intent i = new Intent(this, preferences.class);
            startActivity(i);
        }

        return super.onOptionsItemSelected(item);
    }

}
