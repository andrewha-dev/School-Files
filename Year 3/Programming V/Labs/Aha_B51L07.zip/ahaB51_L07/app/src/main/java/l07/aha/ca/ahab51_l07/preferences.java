package l07.aha.ca.ahab51_l07;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.Objects;

public class preferences extends AppCompatActivity {
    public static String PREF = "MyPrefFiles";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferences);
        TextView firstName = (TextView) findViewById(R.id.txtFirstNameP);
        TextView lastName = (TextView) findViewById(R.id.txtLastNameP);
        TextView email = (TextView) findViewById(R.id.txtEmailP);
        TextView dept = (TextView) findViewById(R.id.txtDeptP);
        SharedPreferences prefs = getSharedPreferences(PREF, MODE_PRIVATE);

        // Read the Shared Preferences vales
        String sfirstName = prefs.getString("firstName","none");
        String slastName = prefs.getString("lastName","none");
        String sEmail = prefs.getString("email","none");
        int iDept = prefs.getInt("dept", -1);


        // If the values are not default, then they exist so use them
        if (!sfirstName.equals("none")){
            firstName.setText(sfirstName);
        }
        if (!slastName.equals("none")){
            lastName.setText(slastName);
        }
        if (!sEmail.equals("none")){
            email.setText(sEmail);
        }
        if (iDept > -1){
            dept.setText(String.valueOf(iDept));
        }

    }

    public void onStop() {
        super.onStop();

        TextView firstName = (TextView) findViewById(R.id.txtFirstNameP);
        TextView lastName = (TextView) findViewById(R.id.txtLastNameP);
        TextView email = (TextView) findViewById(R.id.txtLastNameP);
        TextView dept = (TextView) findViewById(R.id.txtDeptP);

        SharedPreferences.Editor editor = getSharedPreferences(PREF, MODE_PRIVATE).edit();
        String fName = "";
        if (!firstName.getText().equals(""))
            fName = firstName.getText().toString();

        String lName = "";
        if (!lastName.getText().equals(""))
            lName = lastName.getText().toString();

        String sEmail = "";
        if (!email.getText().equals(""))
            sEmail = email.getText().toString();

        int iDept = -1;
        email.getText().toString();
        if (!dept.getText().equals(""))
           iDept = Integer.parseInt(dept.getText().toString());


        // Write the shared preferences values and commit them
        editor.putString("firstName",fName);
        editor.putString("lastName",lName);
        editor.putString("email", sEmail);
        editor.putInt("dept", iDept);
        editor.commit();
    }

}
