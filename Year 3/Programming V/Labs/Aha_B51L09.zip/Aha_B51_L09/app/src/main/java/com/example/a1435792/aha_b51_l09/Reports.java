package com.example.a1435792.aha_b51_l09;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class Reports extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);
        TableLayout table = (TableLayout) findViewById(R.id.table);
        DatabaseHandler db = new DatabaseHandler(this.getApplicationContext());
        Cursor cursor = db.getAllData();
        if (cursor != null)
        {
            if (cursor.moveToFirst()){
                String firstName = "";
                String lastName = "";
                String email = "";
                String phone = "";
                do{


                    firstName = cursor.getString(cursor.getColumnIndex("firstName"));
                    lastName = cursor.getString(cursor.getColumnIndex("lastName"));
                    email = cursor.getString(cursor.getColumnIndex("email"));
                    phone = cursor.getString(cursor.getColumnIndex("phone"));

                    TableRow row = new TableRow(this);
                    // create a new TextView for showing xml data
                    TextView t = new TextView(this);
                    TextView emailTV = new TextView(this);
                    TextView phoneTV = new TextView(this);
                    // set the text to "text xx"
                    t.setText(firstName + " " + lastName);
                    // add the TextView  to the new TableRow
                    emailTV.setText(email);
                    phoneTV.setText(phone);


                    row.addView(t);
                    row.addView(emailTV);
                    row.addView(phoneTV);
                    // add the TableRow to the TableLayout
                    table.addView(row, new TableLayout.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));





                }while(cursor.moveToNext());


            }
            cursor.close();
        }
    }
}
