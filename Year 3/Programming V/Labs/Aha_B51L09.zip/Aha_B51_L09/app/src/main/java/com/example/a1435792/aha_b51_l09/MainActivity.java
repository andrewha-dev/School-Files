package com.example.a1435792.aha_b51_l09;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnGetInfo = (Button) findViewById(R.id.btnGetInfo);
        Button btnUseInfo = (Button) findViewById(R.id.btnUseInfo);

        btnGetInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(), GetInformation.class);
                startActivity(i);
            }
        });

        btnUseInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(view.getContext(), UseInformation.class);
                startActivity(i);
            }
        });
    }
}
