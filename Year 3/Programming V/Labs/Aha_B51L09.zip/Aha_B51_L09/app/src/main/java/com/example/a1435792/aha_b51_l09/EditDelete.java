package com.example.a1435792.aha_b51_l09;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class EditDelete extends AppCompatActivity {
    ArrayList listOfIds;
    ArrayList names;
    int ToUpdate = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_delete);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Spinner s = (Spinner) findViewById(R.id.ddlContacts);
        DatabaseHandler db = new DatabaseHandler(this.getApplicationContext());
        //Loading the spinner
        listOfIds = db.getAllIDs();

        names = db.getInfoName();
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, names);

        Button btnUpdate = (Button) findViewById(R.id.btnUpdate);

        Button btnDelete = (Button) findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHandler db = new DatabaseHandler(view.getContext());
                db.deleteContact(ToUpdate);
                Context context = getApplicationContext();
                CharSequence text = "Contact Deleted!";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                finish();
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHandler db = new DatabaseHandler(view.getContext());
                EditText fnametxt = (EditText) findViewById(R.id.txtEditFirstName);
                EditText lnametxt = (EditText) findViewById(R.id.txtEditLastName);
                EditText emailtxt = (EditText) findViewById(R.id.txtEditEmail);
                EditText phonetxt = (EditText) findViewById(R.id.txtEditPhoneExtension);

                db.updateContact(ToUpdate, fnametxt.getText().toString(), lnametxt.getText().toString(), emailtxt.getText().toString(), phonetxt.getText().toString());
                Context context = getApplicationContext();
                CharSequence text = "Contact Updated!";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                finish();
            }
        });



        s.setAdapter(arrayAdapter);
        s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                System.out.println(listOfIds.get(position));
                setFields(Integer.parseInt(listOfIds.get(position).toString()));
                ToUpdate = Integer.parseInt(listOfIds.get(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });
    }

    public void setFields(int id)
    {
        DatabaseHandler db = new DatabaseHandler(this.getApplicationContext());
        Cursor cursor = db.getData(id);
        if (cursor != null)
        {
            if (cursor.moveToFirst()){
                String firstName = "";
                String lastName = "";
                String email = "";
                String phone = "";
                do{


                    firstName = cursor.getString(cursor.getColumnIndex("firstName"));
                    lastName = cursor.getString(cursor.getColumnIndex("lastName"));
                    email = cursor.getString(cursor.getColumnIndex("email"));
                    phone = cursor.getString(cursor.getColumnIndex("phone"));




                }while(cursor.moveToNext());

                EditText fnametxt = (EditText) findViewById(R.id.txtEditFirstName);
                EditText lnametxt = (EditText) findViewById(R.id.txtEditLastName);
                EditText emailtxt = (EditText) findViewById(R.id.txtEditEmail);
                EditText phonetxt = (EditText) findViewById(R.id.txtEditPhoneExtension);

                fnametxt.setText(firstName);
                lnametxt.setText(lastName);
                emailtxt.setText(email);
                phonetxt.setText(phone);
            }
            cursor.close();
        }

    }


}
