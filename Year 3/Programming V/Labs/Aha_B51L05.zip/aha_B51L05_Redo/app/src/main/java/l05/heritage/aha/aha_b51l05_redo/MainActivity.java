package l05.heritage.aha.aha_b51l05_redo;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

    public class MainActivity extends AppCompatActivity implements View.OnClickListener{
        static String xOrY = "X";
        static int numberClicked = 0;
        static String[] game = new String[] {"0", "1", "2", "3", "4", "5", "6", "7", "8"};


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            Button btn1 = (Button) findViewById(R.id.btnTopLeft);
            Button btn2 = (Button) findViewById(R.id.btnTopMid);
            Button btn3 = (Button) findViewById(R.id.btnTopRight);
            Button btn4 = (Button) findViewById(R.id.btnMidLeft);
            Button btn5 = (Button) findViewById(R.id.btnMidMid);
            Button btn6 = (Button) findViewById(R.id.btnMidRight);
            Button btn7 = (Button) findViewById(R.id.btnBotLeft);
            Button btn8 = (Button) findViewById(R.id.btnBotMid);
            Button btn9 = (Button) findViewById(R.id.btnBotRight);



            btn1.setOnClickListener(this);
            btn2.setOnClickListener(this);
            btn3.setOnClickListener(this);
            btn4.setOnClickListener(this);
            btn5.setOnClickListener(this);
            btn6.setOnClickListener(this);
            btn7.setOnClickListener(this);
            btn8.setOnClickListener(this);
            btn9.setOnClickListener(this);

            if (savedInstanceState != null)
            {
                game = savedInstanceState.getStringArray("game");
                xOrY = savedInstanceState.getString("XY");
                numberClicked = savedInstanceState.getInt("clicks");
                setButtons();
            }



        }

        public void setButtons()
        {
            Button btn1 = (Button) findViewById(R.id.btnTopLeft);
            Button btn2 = (Button) findViewById(R.id.btnTopMid);
            Button btn3 = (Button) findViewById(R.id.btnTopRight);
            Button btn4 = (Button) findViewById(R.id.btnMidLeft);
            Button btn5 = (Button) findViewById(R.id.btnMidMid);
            Button btn6 = (Button) findViewById(R.id.btnMidRight);
            Button btn7 = (Button) findViewById(R.id.btnBotLeft);
            Button btn8 = (Button) findViewById(R.id.btnBotMid);
            Button btn9 = (Button) findViewById(R.id.btnBotRight);
            if (!game[0].equals("0"))
                btn1.setText(game[0]);
            if (!game[1].equals("1"))
                btn2.setText(game[1]);
            if (!game[2].equals("2"))
                btn3.setText(game[2]);
            if (!game[3].equals("3"))
                btn4.setText(game[3]);
            if (!game[4].equals("4"))
                btn5.setText(game[4]);
            if (!game[5].equals("5"))
                btn6.setText(game[5]);
            if (!game[6].equals("6"))
                btn7.setText(game[6]);
            if (!game[7].equals("7"))
                btn8.setText(game[7]);
            if (!game[8].equals("8"))
                btn9.setText(game[8]);

        }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == (R.id.action_newGame))
        {
            Button btn1 = (Button) findViewById(R.id.btnTopLeft);
            Button btn2 = (Button) findViewById(R.id.btnTopMid);
            Button btn3 = (Button) findViewById(R.id.btnTopRight);
            Button btn4 = (Button) findViewById(R.id.btnMidLeft);
            Button btn5 = (Button) findViewById(R.id.btnMidMid);
            Button btn6 = (Button) findViewById(R.id.btnMidRight);
            Button btn7 = (Button) findViewById(R.id.btnBotLeft);
            Button btn8 = (Button) findViewById(R.id.btnBotMid);
            Button btn9 = (Button) findViewById(R.id.btnBotRight);



            btn1.setText("");
            btn2.setText("");
            btn3.setText("");
            btn4.setText("");
            btn5.setText("");
            btn6.setText("");
            btn7.setText("");
            btn8.setText("");
            btn9.setText("");


            btn1.setClickable(true);
            btn2.setClickable(true);
            btn3.setClickable(true);
            btn4.setClickable(true);
            btn5.setClickable(true);
            btn6.setClickable(true);
            btn7.setClickable(true);
            btn8.setClickable(true);
            btn9.setClickable(true);

            TextView lblRes = (TextView) findViewById(R.id.lblRes);
            lblRes.setText("");
            game = new String[] {"0", "1", "2", "3", "4", "5", "6", "7", "8"};
            xOrY = "X";

            numberClicked = 0;

        }
        else
            if (id == R.id.action_exit)
                finish();


        return super.onOptionsItemSelected(item);
    }

    public void handleClick(Button b)
    {
        numberClicked++;
        b.setText(xOrY);
        b.setClickable(false);

        checkGame();


    }

    public void changeXOrY()
    {
        if (xOrY.equals("X"))
            xOrY = "O";
        else
            xOrY = "X";
    }

    public void checkGame()
    {
        if (game[0].equals(game[1]) && game[1] == game[2])
        {
            endGame(game[0], "Wins!");
        }
        else
            if (game[3].equals(game[4]) && game[4] == game[5])
            {
                endGame(game[3], "Wins!");
            }
            else
            if (game[6].equals(game[7]) && game[7] == game[8])
            {
                endGame(game[6], "Wins!");
            }
            else
            if (game[0].equals(game[3]) && game[3] == game[6])
            {
                endGame(game[0], "Wins!");
            }
            else if (game[1].equals(game[4]) && game[4] == game[7])
            {
                endGame(game[1], "Wins!");
            }
            else if (game[2].equals(game[5]) && game[5] == game[8])
            {
                endGame(game[2], "Wins!");
            }
            else if (game[0].equals(game[4]) && game[4] == game[8])
            {
                endGame(game[0], "Wins!");
            }
            else if (game[6].equals(game[4]) && game[4] == game[2])
            {
                endGame(game[6], "Wins!");
            }
            else
                if(numberClicked == 9)
                endGame("Its a", "Tie");
    }

        public void endGame(String _input, String _cond)
        {
            TextView lblRes = (TextView) findViewById(R.id.lblRes);
            lblRes.setText(_input + " " + _cond);
            //System.out.println(game.toString());
            setUnclick();
        }

        public void setUnclick()
        {
            Button btn1 = (Button) findViewById(R.id.btnTopLeft);
            Button btn2 = (Button) findViewById(R.id.btnTopMid);
            Button btn3 = (Button) findViewById(R.id.btnTopRight);
            Button btn4 = (Button) findViewById(R.id.btnMidLeft);
            Button btn5 = (Button) findViewById(R.id.btnMidMid);
            Button btn6 = (Button) findViewById(R.id.btnMidRight);
            Button btn7 = (Button) findViewById(R.id.btnBotLeft);
            Button btn8 = (Button) findViewById(R.id.btnBotMid);
            Button btn9 = (Button) findViewById(R.id.btnBotRight);



            btn1.setClickable(false);
            btn2.setClickable(false);
            btn3.setClickable(false);
            btn4.setClickable(false);
            btn5.setClickable(false);
            btn6.setClickable(false);
            btn7.setClickable(false);
            btn8.setClickable(false);
            btn9.setClickable(false);
        }

        @Override
        public void onSaveInstanceState(Bundle savedInstance)
        {
            savedInstance.putStringArray("game", game);
            savedInstance.putString("XY", xOrY);
            savedInstance.putInt("clicks", numberClicked);
            super.onSaveInstanceState(savedInstance);
        }

        @Override
        public void onRestoreInstanceState(Bundle savedInstanceBundle)
        {
            super.onRestoreInstanceState(savedInstanceBundle);
            game = savedInstanceBundle.getStringArray("game");
            xOrY = savedInstanceBundle.getString("XY");
            numberClicked = savedInstanceBundle.getInt("clicks");
            setButtons();

        }

        @Override
        public void onClick(View v)
        {
            switch (v.getId())
            {
                case R.id.btnTopLeft:
                    handleClick((Button) findViewById(R.id.btnTopLeft));
                    game[0] = xOrY;
                    changeXOrY();
                    checkGame();
                    break;
                case R.id.btnTopMid:
                    handleClick((Button) findViewById(R.id.btnTopMid));
                    game[1] = xOrY;
                    changeXOrY();
                    checkGame();
                    break;
                case R.id.btnTopRight:
                    handleClick((Button) findViewById(R.id.btnTopRight));
                    game[2] = xOrY;
                    changeXOrY();
                    checkGame();
                    break;
                case R.id.btnMidLeft:
                    handleClick((Button) findViewById(R.id.btnMidLeft));
                    game[3] = xOrY;
                    changeXOrY();
                    checkGame();
                    break;
                case R.id.btnMidMid:
                    handleClick((Button) findViewById(R.id.btnMidMid));
                    game[4] = xOrY;
                    changeXOrY();
                    checkGame();
                    break;
                case R.id.btnMidRight:
                    handleClick((Button) findViewById(R.id.btnMidRight));
                    game[5] = xOrY;
                    changeXOrY();
                    checkGame();
                    break;
                case R.id.btnBotLeft:
                    handleClick((Button) findViewById(R.id.btnBotLeft));
                    game[6] = xOrY;
                    changeXOrY();
                    checkGame();
                    break;
                case R.id.btnBotMid:
                    handleClick((Button) findViewById(R.id.btnBotMid));
                    game[7] = xOrY;
                    changeXOrY();
                    checkGame();
                    break;
                case R.id.btnBotRight:
                    handleClick((Button) findViewById(R.id.btnBotRight));
                    game[8] = xOrY;
                    changeXOrY();
                    checkGame();
                    break;
            }
        }





    }
