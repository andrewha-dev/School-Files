package com.example.a1435792.aha_b51l02;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnAdd = (Button) findViewById(R.id.btnPlus);
        Button btnSub = (Button) findViewById(R.id.btnSub);
        Button btnMult = (Button) findViewById(R.id.btnMult);
        Button btnDiv = (Button) findViewById(R.id.btnDivide);
        Button btnSquare = (Button) findViewById(R.id.btnSquare);
        Button btnCube = (Button) findViewById(R.id.btnCube);
        Button btnSqrt = (Button) findViewById(R.id.btnSqrt);
        Button btnPercent = (Button) findViewById(R.id.btnPercent);

        final EditText edtInput1 = (EditText) findViewById(R.id.edtInput1);
        final EditText edtInput2 = (EditText) findViewById(R.id.edtInput2);
        final TextView txtAnswer = (TextView) findViewById(R.id.txtAnswer);



        btnAdd.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                double inputDouble = Double.parseDouble(edtInput1.getText().toString());
                double inputDouble2 = Double.parseDouble(edtInput2.getText().toString());
                double answer = inputDouble + inputDouble2;

                txtAnswer.setText(String.format("%.2f", answer));
            }
        });

        btnSub.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                double inputDouble = Double.parseDouble(edtInput1.getText().toString());
                double inputDouble2 = Double.parseDouble(edtInput2.getText().toString());
                double answer = inputDouble - inputDouble2;

                txtAnswer.setText(String.format("%.2f", answer));
            }
        });

        btnMult.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                double inputDouble = Double.parseDouble(edtInput1.getText().toString());
                double inputDouble2 = Double.parseDouble(edtInput2.getText().toString());
                double answer = inputDouble * inputDouble2;

                txtAnswer.setText(String.format("%.2f", answer));
            }
        });

        btnDiv.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                double inputDouble = Double.parseDouble(edtInput1.getText().toString());
                double inputDouble2 = Double.parseDouble(edtInput2.getText().toString());
                double answer = inputDouble / inputDouble2;

                txtAnswer.setText(String.format("%.2f", answer));
            }
        });

        btnSquare.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                double inputDouble = Double.parseDouble(edtInput1.getText().toString());
                double inputDouble2 = Double.parseDouble(edtInput2.getText().toString());
                double answer = inputDouble * inputDouble;

                txtAnswer.setText(String.format("%.2f", answer));
            }
        });

        btnCube.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                double inputDouble = Double.parseDouble(edtInput1.getText().toString());
                double inputDouble2 = Double.parseDouble(edtInput2.getText().toString());
                double answer = inputDouble * inputDouble * inputDouble;

                txtAnswer.setText(String.format("%.2f", answer));
            }
        });

        btnSqrt.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                double inputDouble = Double.parseDouble(edtInput1.getText().toString());
                double inputDouble2 = Double.parseDouble(edtInput2.getText().toString());
                double answer = Math.sqrt(inputDouble);

                txtAnswer.setText(String.format("%.2f", answer));
            }
        });

        btnPercent.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                double inputDouble = Double.parseDouble(edtInput1.getText().toString());
                double inputDouble2 = Double.parseDouble(edtInput2.getText().toString());
                double answer = inputDouble % inputDouble2;

                txtAnswer.setText(String.format("%.2f", answer));
            }
        });







    }
}
