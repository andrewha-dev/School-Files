package com.example.a1435792.aha_b51l03;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.view.View;


public class MainActivity extends AppCompatActivity {
    static double answer = 0.0;
    static String lastOp = "";
    static String currentOp = "";
    static String opOrNumber = "";
    //static String veryLastNumber = "";
    //static String lastNumber = "";
    static double prevNumber = 0.0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageButton btnAdd = (ImageButton) findViewById(R.id.btnAdd);
        ImageButton btnSub = (ImageButton) findViewById(R.id.btnMinus);
        ImageButton btnMult = (ImageButton) findViewById(R.id.btnMult);
        ImageButton btnDiv = (ImageButton) findViewById(R.id.btnDiv);
        ImageButton btnSquare = (ImageButton) findViewById(R.id.btnSquare);
        ImageButton btnCube = (ImageButton) findViewById(R.id.btnCube);
        ImageButton btnSqrt = (ImageButton) findViewById(R.id.btnSqrt);
        ImageButton btnInverse = (ImageButton) findViewById(R.id.btnInv);
        ImageButton btnDec = (ImageButton) findViewById(R.id.btnDecimal);
        ImageButton btnEqual = (ImageButton) findViewById(R.id.btnEqual);
        ImageButton btnZero = (ImageButton) findViewById(R.id.btnZero);
        ImageButton btnOne = (ImageButton) findViewById(R.id.btnOne);
        ImageButton btnTwo = (ImageButton) findViewById(R.id.btnTwo);
        ImageButton btnThree = (ImageButton) findViewById(R.id.btnThree);
        ImageButton btnFour = (ImageButton) findViewById(R.id.btnFour);
        ImageButton btnFive = (ImageButton) findViewById(R.id.btnFive);
        ImageButton btnSix = (ImageButton) findViewById(R.id.btnSix);
        ImageButton btnSeven = (ImageButton) findViewById(R.id.btnSeven);
        ImageButton btnEight = (ImageButton) findViewById(R.id.btnEight);
        ImageButton btnNine = (ImageButton) findViewById(R.id.btnNine);
        Button btnClear = (Button) findViewById(R.id.btnClear);
        final EditText txtRes = (EditText) findViewById(R.id.txtPreviewAnswer);

        try {
            btnAdd.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    if (!opOrNumber.equals("op"))
                    {
                        String res = txtRes.getText().toString();
                        txtRes.setText(res + " + ");
                    }
                    opOrNumber = "op";

                }
            });

            btnSub.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    if (!opOrNumber.equals("op"))
                    {
                        String res = txtRes.getText().toString();
                        txtRes.setText(res + " - ");
                    }
                    opOrNumber = "op";
                }

            });

            btnMult.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    if (!opOrNumber.equals("op"))
                    {
                        String res = txtRes.getText().toString();
                        txtRes.setText(res + " * ");
                    }
                    opOrNumber = "op";
                }
            });

            btnDiv.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    if (!opOrNumber.equals("op"))
                    {
                        String res = txtRes.getText().toString();
                        txtRes.setText(res + " / ");
                    }
                    opOrNumber = "op";
                }
            });

            btnSquare.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    double res = calc();
                    double answer = Math.pow(res, 2);
                    txtRes.setText(String.valueOf(answer));
                }
            });

            btnCube.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    double res = calc();
                    double answer = Math.pow(res, 3);
                    txtRes.setText(String.valueOf(answer));
                }
            });

            btnInverse.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    double res = calc();
                    double answer = Math.pow(res, -1);
                    txtRes.setText(String.valueOf(answer));
                }
            });

            btnSqrt.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    double res = calc();
                    double answer = Math.sqrt(res);
                    txtRes.setText(String.valueOf(answer));
                }
            });



            btnClear.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    txtRes.setText("");
                    answer = 0.0;
                    txtRes.setText("");
                    opOrNumber = "";

                }
            });

            btnZero.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String res = txtRes.getText().toString();
                    txtRes.setText(res + "0");
                    opOrNumber = "num";
                }
            });

            btnOne.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String res = txtRes.getText().toString();
                    txtRes.setText(res + "1");
                    opOrNumber = "num";
                }
            });

            btnTwo.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String res = txtRes.getText().toString();
                    txtRes.setText(res + "2");
                    opOrNumber = "num";
                }
            });

            btnThree.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String res = txtRes.getText().toString();
                    txtRes.setText(res + "3");
                    opOrNumber = "num";
                }
            });

            btnFour.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String res = txtRes.getText().toString();
                    txtRes.setText(res + "4");
                    opOrNumber = "num";
                }
            });

            btnFive.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String res = txtRes.getText().toString();
                    txtRes.setText(res + "5");
                    opOrNumber = "num";
                }
            });

            btnSix.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String res = txtRes.getText().toString();
                    txtRes.setText(res + "6");
                    opOrNumber = "num";
                }
            });

            btnSeven.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String res = txtRes.getText().toString();
                    txtRes.setText(res + "7");
                    opOrNumber = "num";
                }
            });

            btnEight.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String res = txtRes.getText().toString();
                    txtRes.setText(res + "8");
                    opOrNumber = "num";
                }
            });

            btnNine.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String res = txtRes.getText().toString();
                    txtRes.setText(res + "9");
                    opOrNumber = "num";
                }
            });

            btnDec.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (!opOrNumber.equals("dec"))
                    {
                        String res = txtRes.getText().toString();
                        txtRes.setText(res + ".");
                    }
                    opOrNumber = "dec";
                }
            });

            btnEqual.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String lastop = "";
                    String eq = txtRes.getText().toString();
                    double result = 0.0;

                    String [] split = eq.split("\\s");

                    for (String s : split) {
                        switch (s)
                        {
                            case "+":
                                lastop = "+";
                                break;
                            case "-":
                                lastop = "-";
                                break;
                            case "*":
                                lastop = "*";
                                break;
                            case "/":
                                lastop = "/";
                                break;
                            case "^1/2":
                                lastop = "^1/2";
                                break;
                            case "^2":
                                lastop = "^2";
                                break;
                            case "^3":
                                lastop = "^3";
                                break;
                            case "^-1":
                                lastop = "^-1";
                                break;
                            default:
                                switch (lastop)
                                {
                                    case "+":
                                        result += Double.parseDouble(s);
                                        break;
                                    case "-":
                                        result -= Double.parseDouble(s);
                                        break;
                                    case "*":
                                        result *= Double.parseDouble(s);
                                        break;
                                    case "/":
                                        result /= Double.parseDouble(s);
                                        break;
                                    case "^1/2":
                                        break;
                                    case "^2":
                                        break;
                                    case "^3":
                                        break;
                                    case "^-1":
                                        break;
                                    default:
                                        if (result == 0.0)
                                            result = Double.parseDouble(s);
                                        else {
                                            result += Double.parseDouble(s);
                                        }
                                        break;
                                }
                                break;
                        }
                    }

                    txtRes.setText(String.valueOf(result));
                    opOrNumber = "eq";
                }
            });
        }

        catch (Exception e){
            txtRes.setText("Error");
        }



    }

    private double calc()
    {
        final EditText txtRes = (EditText) findViewById(R.id.txtPreviewAnswer);
        String txtResStr = txtRes.getText().toString();
        String lastop = "";
        String eq = txtRes.getText().toString();
        double result = 0.0;

        String [] split = eq.split("\\s");

        for (String s : split) {
            switch (s)
            {
                case "+":
                    lastop = "+";
                    break;
                case "-":
                    lastop = "-";
                    break;
                case "*":
                    lastop = "*";
                    break;
                case "/":
                    lastop = "/";
                    break;
                case "^1/2":
                    lastop = "^1/2";
                    break;
                case "^2":
                    lastop = "^2";
                    break;
                case "^3":
                    lastop = "^3";
                    break;
                case "^-1":
                    lastop = "^-1";
                    break;
                default:
                    switch (lastop)
                    {
                        case "+":
                            result += Double.parseDouble(s);
                            break;
                        case "-":
                            result -= Double.parseDouble(s);
                            break;
                        case "*":
                            result *= Double.parseDouble(s);
                            break;
                        case "/":
                            result /= Double.parseDouble(s);
                            break;
                        case "^1/2":
                            break;
                        case "^2":
                            break;
                        case "^3":
                            break;
                        case "^-1":
                            break;
                        default:
                            if (result == 0.0)
                                result = Double.parseDouble(s);
                            else {
                                result += Double.parseDouble(s);
                            }
                            break;
                    }
                    break;
            }
        }



        return result;
    }

//    private double calcPrev(String _eq)
//    {
//        String lastOp = "";
//        double res = 0.0;
//        double storedNumber = 0.0;
//        String eq = _eq;
//        String[] eqParts = eq.split(" ");
//        Console.log(eqParts.length);
//        for (int i = 0; i < eqParts.length; i++)
//        {
//            switch (eqParts[i])
//            {
//                case "+":
//                    lastOp = "+";
//                    break;
//                case "-":
//                    lastOp = "-";
//                    break;
//                case "*":
//                    lastOp = "*";
//                    break;
//                case "/":
//                    lastOp = "/";
//                    break;
//                case "^":
//                    lastOp = "^";
//                    break;
//                case "^2":
//                    lastOp = "^2";
//                    break;
//                case "^3":
//                    lastOp = "^3";
//                    break;
//                case "^-1":
//                    lastOp = "^-1";
//                    break;
//                case "^1/2":
//                    lastOp = "^1/2";
//                    break;
//                default:
//                    if (lastOp.equals(""))
//                        res = storedNumber;
//                    storedNumber = Double.parseDouble(eqParts[i]);
//
//                    if (!lastOp.equals(""))
//                    switch (lastOp)
//                    {
//                        case "+":
//                            res += storedNumber;
//                            break;
//                        case "-":
//                            res -= storedNumber;
//                            break;
//                        case "*":
//                            res *= storedNumber;
//                            break;
//                        case "/":
//                            res /= storedNumber;
//                            break;
//
//                    }
//
//                    break;
//            }
//        }
//    return res;
//    }
}
