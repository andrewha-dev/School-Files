package com.example.a1435792.aha_l01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView input = (TextView) findViewById(R.id.txtInput);
        final TextView result = (TextView) findViewById(R.id.txtAnswer);
        Button celToFahr = (Button) findViewById(R.id.btnCelToFahr);
        Button cmToInch = (Button) findViewById(R.id.btnCmToInch);
        Button gramToOz = (Button) findViewById(R.id.btnGramToOz);
        Button kgToLbs = (Button) findViewById(R.id.btnKgToLbs);
        final CheckBox toggle = (CheckBox) findViewById(R.id.chkToggle);

        celToFahr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (toggle.isChecked() == false)
                {
                    double value = Double.parseDouble(input.getText().toString());
                    double converted = value * 9 / 5 + 32;
                    converted = Math.round(converted*100.0)/100.00;
                    result.setText((value) + " Celsius =  " + converted + " Fahrenheit ");
                }
                else {
                    double value = Double.parseDouble(input.getText().toString());
                    double converted = (value - 32.0) * 5/9;
                    converted = Math.round(converted*100.0)/100.00;
                    result.setText((value) + " Fahrenheit =  " + converted + " Celsius ");
                }

            }
        });
        cmToInch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (toggle.isChecked() == false)
                {
                    double value = Double.parseDouble(input.getText().toString());
                    double converted = value / 2.54;
                    converted = Math.round(converted*100.0)/100.00;
                    result.setText((value) + " Cm =  " + converted + " Inches ");
                }
                else {
                    double value = Double.parseDouble(input.getText().toString());
                    double converted = value * 2.54;
                    converted = Math.round(converted*100.0)/100.00;
                    result.setText((value) + " Inches =  " + converted + " Cm ");
                }
            }
        });
        gramToOz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (toggle.isChecked() == false)
                {
                    double value = Double.parseDouble(input.getText().toString());
                    double converted = value / 28.35;
                    converted = Math.round(converted*100.0)/100.00;
                    result.setText((value) + " Grams =  " + converted + " Oz ");
                }
                else {
                    double value = Double.parseDouble(input.getText().toString());
                    double converted = value * 28.35;
                    converted = Math.round(converted*100.0)/100.00;
                    result.setText((value) + " Oz =  " + converted + " Grams ");
                }
            }
        });
        kgToLbs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (toggle.isChecked() == false)
                {
                    double value = Double.parseDouble(input.getText().toString());
                    double converted = value * 2.2;
                    converted = Math.round(converted*100.0)/100.00;
                    result.setText((value) + " Lbs =  " + converted + " KG ");
                }
                else {
                    double value = Double.parseDouble(input.getText().toString());
                    double converted = value / 2.2;
                    converted = Math.round(converted*100.0)/100.00;
                    result.setText((value) + " KG =  " + converted + " Lbs ");
                }
            }
        });




    }
}
