package com.aha.ca.aha_l04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends AppCompatActivity {
    public static int CalcTipCode = 1;
    public static int CalcShareCode = 2;
    static double totalTipAmount = 0.0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        findViewById(R.id.btnCalcTip).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this, CalculateTip.class);
                startActivityForResult(i, CalcTipCode);
            }
        });

        findViewById(R.id.btnAbout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this, About.class);
                startActivity(i);

            }
        });

        findViewById(R.id.btnCalculateShare).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this, CalcShare.class);
                i.putExtra("tip", totalTipAmount);
                startActivityForResult(i, CalcShareCode);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK)
        {
            if (requestCode == CalcTipCode){
                totalTipAmount = Double.parseDouble(data.getStringExtra("tipAmount"));
            }
        }
    }
}
