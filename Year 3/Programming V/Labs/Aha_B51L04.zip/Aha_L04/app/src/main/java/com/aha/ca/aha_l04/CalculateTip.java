package com.aha.ca.aha_l04;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.SeekBar;
import android.widget.EditText;
import android.widget.TextView;

public class CalculateTip extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate_tip);
        final EditText amount = (EditText) findViewById(R.id.txtAmount);
        final SeekBar mySB = (SeekBar) findViewById(R.id.sbCustomTip);
        final TextView staticTip = (TextView) findViewById(R.id.txtStatic);
        final TextView staticTotal = (TextView) findViewById(R.id.txtTotalStatic);
        final TextView dynTip = (TextView) findViewById(R.id.txtDync);
        final TextView dynTotal = (TextView) findViewById(R.id.txtTotalDyn);
        mySB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            TextView customTip = (TextView) findViewById(R.id.txtDynTip);
                String theAmount = amount.getText().toString().trim();
                double amountDBL = 0.0;
                if (!theAmount.equals("")) {
                    customTip.setText(mySB.getProgress() + "%");
                    amountDBL = Double.parseDouble(theAmount);
                    double dynPercentage = mySB.getProgress();
                    double tipDynamicAmount = (dynPercentage / 100.00 * amountDBL);
                    double totalDynamicAmount = amountDBL * ((dynPercentage / 100.00) + 1);
                    dynTip.setText("$" + String.format("%.2f", tipDynamicAmount));
                    dynTotal.setText("$" + String.format("%.2f", totalDynamicAmount));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });



        dynTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String theAmount = amount.getText().toString().trim();
                if (!theAmount.equals("") && !dynTotal.getText().equals(""))
                {
                    Intent retData = new Intent();
                    retData.putExtra("tipAmount", dynTotal.getText().toString());
                    setResult(RESULT_OK, retData);
                    finish();
                }
            }
        });

        staticTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String theAmount = amount.getText().toString().trim();
                if (!theAmount.equals("") && !staticTotal.getText().equals(""));
                {
                    Intent retData = new Intent();
                    retData.putExtra("tipAmount", staticTotal.getText().toString());
                    setResult(RESULT_OK, retData);
                    finish();
                }
            }
        });


        amount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String theAmount = amount.getText().toString().trim();
                double amountDBL = 0.0;
                double tipStaticAmount = 0.0;
                double totalStaticAmount = 0.0;
                double dynPercentage = mySB.getProgress();
                double tipDynamicAmount = 0.0;
                double totalDynamicAmount = 0.0;
                if (!theAmount.equals(""))
                {
                    amountDBL = Double.parseDouble(theAmount);
                    tipStaticAmount = amountDBL * 0.15;
                    totalStaticAmount = amountDBL * 1.15;
                    tipDynamicAmount =  (dynPercentage / 100.00 * amountDBL);
                    totalDynamicAmount = amountDBL * ((dynPercentage / 100.00) + 1);

                    staticTip.setText(String.format("%.2f", tipStaticAmount));
                    staticTotal.setText(String.format("%.2f", totalStaticAmount));
                    dynTip.setText(String.format("%.2f", tipDynamicAmount));
                    dynTotal.setText(String.format("%.2f", totalDynamicAmount));

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });



    }
}
