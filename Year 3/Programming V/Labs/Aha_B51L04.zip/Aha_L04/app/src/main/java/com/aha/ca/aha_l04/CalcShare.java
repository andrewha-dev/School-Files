package com.aha.ca.aha_l04;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

public class CalcShare extends AppCompatActivity {
    public static double theValue = 0.0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String value = "";
        theValue = 0.0;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calc_share);
        Bundle extra = getIntent().getExtras();
        if (extra != null){
            theValue = extra.getDouble("tip");
        }
        final TextView amount = (TextView) findViewById(R.id.txtTip);
        amount.setText(String.valueOf(theValue));
        final TextView shareAmount = (TextView) findViewById(R.id.txtSharedAmount);
        final TextView sharedAmount = (TextView) findViewById(R.id.txtPrice);

        final SeekBar share = (SeekBar) findViewById(R.id.sbShare);
        share.setProgress(2);

        share.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (share.getProgress() >= 2 && share.getProgress() <= 12)
                {
                    shareAmount.setText(String.valueOf(share.getProgress()));
                    sharedAmount.setText("$" + String.format("%.2f", (theValue/share.getProgress())));

                }

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }





}
