package a02.aha.ca.aha_b51_a02;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Game extends AppCompatActivity {
    MathMinute game = new MathMinute(MathMinute.Difficulty.EASY, new String[]{"+", "-", "*", "/"});
    CountDownTimer countdown;
    long millisecondsLeft = 60000;
    public static final String EMP_DATA = "MyPrefsFile";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        final TextView timeDisplay = (TextView) findViewById(R.id.lblTimeActual);
        final TextView eqDisplay = (TextView) findViewById(R.id.lblEquationText);
        final Button submit = (Button) findViewById(R.id.btnSubmit);
        final EditText txtAnswer =  (EditText) findViewById(R.id.txtAnswer);
        final TextView lblQuestions = (TextView) findViewById(R.id.lblQuestionsTotalText);
        final TextView lblCorrect = (TextView) findViewById(R.id.lblCorrectTotalText);
        final TextView lblIncorrect = (TextView) findViewById(R.id.lblIncorrectTotalText);
        String eq = "";
        if (savedInstanceState != null)
        {
            millisecondsLeft = savedInstanceState.getLong("millis");
            game.totalQuestions = savedInstanceState.getInt("totalQues");
            game.correctQuestions = savedInstanceState.getInt("correct");
            game.incorrectQuestions = savedInstanceState.getInt("incorrect");
            game.equation = savedInstanceState.getString("currQues");
            eq = game.equation;
            eqDisplay.setText(eq);
            lblQuestions.setText(String.valueOf(game.totalQuestions));
            lblIncorrect.setText(String.valueOf(game.incorrectQuestions));
            lblCorrect.setText(String.valueOf(game.correctQuestions));

        }
        else
        {
            eq = game.generateEquation();
            eqDisplay.setText(eq);
            lblQuestions.setText(String.valueOf(game.totalQuestions));
        }



        //Grabbing from preferences and setting the constructor
        SharedPreferences prefs = getSharedPreferences(EMP_DATA, MODE_PRIVATE);
        prefs.edit().clear().commit();

        String difficulty = prefs.getString("difficulty","none");
        if (difficulty.equals("none"))
            game.diff = MathMinute.Difficulty.EASY;
        if (difficulty.equals("easy"))
            game.diff = MathMinute.Difficulty.EASY;
        if (difficulty.equals("medium"))
            game.diff = MathMinute.Difficulty.MEDIUM;
        if (difficulty.equals("hard"))
            game.diff = MathMinute.Difficulty.HARD;

        boolean add = prefs.getBoolean("add",false);
        boolean sub = prefs.getBoolean("sub",false);
        boolean mult = prefs.getBoolean("mult",false);
        boolean div = prefs.getBoolean("div",false);

        List<String> ops = new ArrayList<String>();
        if (add == true)
            ops.add("+");
        if (sub == true)
            ops.add("-");
        if (mult == true)
            ops.add("*");
        if (div == true)
            ops.add("/");

        if (ops.size() == 0)
        {
            ops.add("+");
            ops.add("-");
            ops.add("*");
            ops.add("/");
        }

        String[] stringArray = new String[ ops.size() ];
        ops.toArray( stringArray );

        game.operatorsChosen = stringArray;

        countdown = new CountDownTimer(millisecondsLeft, 1000) {

            public void onTick(long millisUntilFinished) {
                timeDisplay.setText(String.valueOf(millisUntilFinished / 1000));
                millisecondsLeft = millisUntilFinished;
            }

            public void onFinish() {
                timeDisplay.setText("Out of Time!");
                submit.setEnabled(false);
                Intent i = new Intent(Game.this, Results.class);
                i.putExtra("total", game.totalQuestions);
                i.putExtra("correct", game.correctQuestions);
                i.putExtra("incorrect", game.incorrectQuestions);
                startActivity(i);
                finish();
            }
        }.start();


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //Gets the users answer
                String userAnswer = txtAnswer.getText().toString();
                txtAnswer.setText("");
                Double userAnswerDouble = 0.0;
                if (!userAnswer.equals(""))
                {
                    userAnswerDouble = Double.parseDouble(userAnswer);
                }
                else{
                    if (game.answer != 0.0)
                    userAnswerDouble = 0.0;
                    else
                        if (game.answer != -1.0)
                        userAnswerDouble = -1.0;
                }


                game.checkAnswer(userAnswerDouble);

                //Gets the next set of questions
                String eq = game.generateEquation();
                eqDisplay.setText(eq);
                lblQuestions.setText(String.valueOf(game.totalQuestions));
                lblIncorrect.setText(String.valueOf(game.incorrectQuestions));
                lblCorrect.setText(String.valueOf(game.correctQuestions));

            }
        });


    }

    @Override
    protected void onPause()
    {
        super.onPause();
        //Gets the current pause
        final TextView timeDisplay = (TextView) findViewById(R.id.lblTimeActual);
        String equations = game.equation;
        int totalQues = game.totalQuestions;
        int correct = game.correctQuestions;
        int incorrect = game.incorrectQuestions;
        countdown.cancel();
        SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
        editor.putString("currQues", equations);
        editor.putInt("total", totalQues);
        editor.putInt("correct", correct);
        editor.putInt("incorrect", incorrect);
        editor.putLong("currTime", millisecondsLeft);
        editor.commit();
    }

    @Override
    protected void onStop()
    {
        super.onStop();
        final TextView timeDisplay = (TextView) findViewById(R.id.lblTimeActual);
        String equations = game.equation;
        int totalQues = game.totalQuestions;
        int correct = game.correctQuestions;
        int incorrect = game.incorrectQuestions;
        countdown.cancel();
        SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
        editor.putString("currQues", equations);
        editor.putInt("total", totalQues);
        editor.putInt("correct", correct);
        editor.putInt("incorrect", incorrect);
        editor.putLong("currTime", millisecondsLeft);
    }

    @Override
    protected void onStart()
    {
        super.onStart();
        final TextView timeDisplay = (TextView) findViewById(R.id.lblTimeActual);
        final TextView eqDisplay = (TextView) findViewById(R.id.lblEquationText);
        final TextView lblQuestions = (TextView) findViewById(R.id.lblQuestionsTotalText);
        final TextView lblCorrect = (TextView) findViewById(R.id.lblCorrectTotalText);
        final TextView lblIncorrect = (TextView) findViewById(R.id.lblIncorrectTotalText);
        SharedPreferences prefs = getSharedPreferences(EMP_DATA, MODE_PRIVATE);
        String currQues = prefs.getString("currQues","");
        int total = prefs.getInt("total", -1);
        int correct = prefs.getInt("correct", -1);
        int incorrect = prefs.getInt("incorrect", -1);
        long timeLeft = prefs.getLong("currTime", -1);
        if (!currQues.equals(""))
        {
            game.equation = currQues;
            eqDisplay.setText(currQues);
        }
        if (total != -1)
        {
            game.totalQuestions = total;
            lblQuestions.setText(String.valueOf(total));
        }
        if (correct != -1)
        {
            game.correctQuestions = correct;
            lblCorrect.setText(String.valueOf(correct));
        }
        if (incorrect != -1)
        {
            game.incorrectQuestions = incorrect;
            lblIncorrect.setText(String.valueOf(incorrect));
        }

        if (timeLeft != -1)
        {
            final Button submit = (Button) findViewById(R.id.btnSubmit);
            countdown = new CountDownTimer(timeLeft, 1000) {

                public void onTick(long millisUntilFinished) {
                    timeDisplay.setText(String.valueOf(millisUntilFinished / 1000));
                    millisecondsLeft = millisUntilFinished;
                }

                public void onFinish() {
                    timeDisplay.setText("Out of Time!");
                    submit.setEnabled(false);
                    Intent i = new Intent(Game.this, Results.class);
                    i.putExtra("total", game.totalQuestions);
                    i.putExtra("correct", game.correctQuestions);
                    i.putExtra("incorrect", game.incorrectQuestions);
                    startActivity(i);
                    finish();
                }
            }.start();
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        final TextView timeDisplay = (TextView) findViewById(R.id.lblTimeActual);
        final TextView eqDisplay = (TextView) findViewById(R.id.lblEquationText);
        final TextView lblQuestions = (TextView) findViewById(R.id.lblQuestionsTotalText);
        final TextView lblCorrect = (TextView) findViewById(R.id.lblCorrectTotalText);
        final TextView lblIncorrect = (TextView) findViewById(R.id.lblIncorrectTotalText);
        SharedPreferences prefs = getSharedPreferences(EMP_DATA, MODE_PRIVATE);
        String currQues = prefs.getString("currQues","");
        int total = prefs.getInt("total", -1);
        int correct = prefs.getInt("correct", -1);
        int incorrect = prefs.getInt("incorrect", -1);
        long timeLeft = prefs.getLong("currTime", -1);
        if (!currQues.equals(""))
        {
            game.equation = currQues;
            eqDisplay.setText(currQues);
        }
        if (total != -1)
        {
            game.totalQuestions = total;
            lblQuestions.setText(String.valueOf(total));
        }
        if (correct != -1)
        {
            game.correctQuestions = correct;
            lblCorrect.setText(String.valueOf(correct));
        }
        if (incorrect != -1)
        {
            game.incorrectQuestions = incorrect;
            lblIncorrect.setText(String.valueOf(incorrect));
        }

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong("millis",  millisecondsLeft);
        outState.putInt("totalQues", game.totalQuestions);
        outState.putInt("correct", game.correctQuestions);
        outState.putInt("incorrect", game.incorrectQuestions);
        outState.putString("currQues", game.equation);

    }

}
