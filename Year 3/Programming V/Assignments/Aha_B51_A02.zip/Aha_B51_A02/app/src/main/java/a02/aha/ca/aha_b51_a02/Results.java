package a02.aha.ca.aha_b51_a02;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Results extends AppCompatActivity {
    public int totalInt = 0;
    public int correctInt = 0;
    public int incorrectInt = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);

        final TextView total = (TextView) findViewById(R.id.lblTotalTextRes);
        final TextView correct = (TextView) findViewById(R.id.lblCorrectTextRes);
        final TextView incorrect = (TextView) findViewById(R.id.lblIncorrectTextRes);
        final TextView percentText = (TextView) findViewById(R.id.lblPercentCorrectTextRes);

        if (savedInstanceState != null) {
            totalInt = savedInstanceState.getInt("total");
            correctInt = savedInstanceState.getInt("correct");
            incorrectInt = savedInstanceState.getInt("incorrect");

        }
        else {
            Intent i = getIntent();
            if (i != null)
            {
                totalInt = i.getIntExtra("total", 0);
                correctInt = i.getIntExtra("correct", 0);
                incorrectInt = i.getIntExtra("incorrect", 0);
            }
        }

        float percentage = 0.0f;

        total.setText(String.valueOf(totalInt));
        correct.setText(String.valueOf(correctInt));
        incorrect.setText(String.valueOf(incorrectInt));

        float percent = (float) correctInt/totalInt * 100;
        percentText.setText(String.valueOf(percent) + "%");

    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("total", totalInt);
        savedInstanceState.putInt("correct", correctInt);
        savedInstanceState.putInt("incorrect", incorrectInt);


    }


}
