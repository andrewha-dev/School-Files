package a02.aha.ca.aha_b51_a02;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;
import java.util.Random;

/**
 * Created by 1435792 on 10/27/2017.
 */

public class MathMinute {
    public static final String EMP_DATA = "MyPrefsFile";
    public static String[] OPERATORS = {"+", "-",  "*", "/"};
    public String[] operatorsChosen;
    public Difficulty diff;
    public String equation;
    public double answer;
    Random rand = new Random();

    public int totalQuestions = 0;
    public int correctQuestions = 0;
    public int incorrectQuestions = 0;

    public enum Difficulty {
        EASY, MEDIUM, HARD
    }

    public MathMinute(Difficulty _diff, String[] _operatorsChosen)
    {
        diff = _diff;
        operatorsChosen = getOperatorsChosen();
        equation = "";

    }


    public String[] getOperatorsChosen()
    {
        return new String[]{"+", "-", "*", "/"};
    }

    public String generateEquation()
    {
        equation = "";
        answer = 0.0;
        int amountOfOperations = 0;
        int firstNum = 0;
        int secondNum = 0;
        int thirdNum = 0;
        int fourthNum = 0;
        String firstOp = "";
        String secondOp = "";
        String thirdOp = "";
        switch(diff)
        {

            case EASY:
                //Rules of Easy: Will only do 1-2 operations, All numbers are from 1-12
                amountOfOperations = rand.nextInt(2) + 1;
                firstNum = rand.nextInt(12) + 1;
                secondNum = rand.nextInt(12) + 1;
                firstOp = operatorsChosen[rand.nextInt(operatorsChosen.length)];
                equation =  firstNum  + " " + firstOp +  " " + secondNum;
                if (amountOfOperations == 2) {
                    secondOp = operatorsChosen[rand.nextInt(operatorsChosen.length)];
                    thirdNum = rand.nextInt(12) + 1;
                    equation += " " + secondOp + " " + thirdNum;
                }
                answer = parseAnswer(equation);
                break;
            case MEDIUM:
                //Rules of Medium: Will do 2 operations, Uses numbers from 12-25
                firstNum = rand.nextInt(15) + 10;
                secondNum = rand.nextInt(15) + 10;
                firstOp = operatorsChosen[rand.nextInt(operatorsChosen.length)];
                equation =  firstNum  + " " + firstOp +  " " + secondNum;
                secondOp = operatorsChosen[rand.nextInt(operatorsChosen.length)];
                thirdNum = rand.nextInt(15) + 10;
                equation += " " + secondOp + " " + thirdNum;
                answer = parseAnswer(equation);
                break;
            case HARD:
                //Rules of Hard: Will do 3 operations, Uses numbers 25-50
                firstNum = rand.nextInt(50) + 25;
                secondNum = rand.nextInt(50) + 25;
                firstOp = operatorsChosen[rand.nextInt(operatorsChosen.length)];
                equation =  firstNum  + " " + firstOp +  " " + secondNum;
                secondOp = operatorsChosen[rand.nextInt(operatorsChosen.length)];
                thirdNum = rand.nextInt(50) + 25;
                equation += " " + secondOp + " " + thirdNum;
                thirdOp = operatorsChosen[rand.nextInt(operatorsChosen.length)];
                fourthNum = rand.nextInt(50) + 25;
                equation += " " + thirdOp + " " + fourthNum;
                answer = parseAnswer(equation);
                break;
            default:
                break;
        }

        return equation + " = ? ";
    }

    public double parseAnswer(String _expression)
    {
        double answer = 0.0;

        String newEquation = "";
        ArrayList<String> equation = new ArrayList<String>(Arrays.asList(_expression.split(" ")));

        while (equation.size() > 1)
        {
            for(int i = 0; i < equation.size(); i++)
            {
                //Look for first multiplication / division
                if (equation.get(i).equals("*") || equation.get(i).equals("/")) {
                    double firstNum = Double.parseDouble(equation.get(i-1));
                    double secondNum = Double.parseDouble(equation.get(i+1));
                    double res;
                    boolean changed = false;
                    if (equation.get(i).equals("*"))
                    {
                        res = firstNum * secondNum;
                        changed = true;
                    }
                    else
                    {
                        res = firstNum / secondNum;
                        changed = true;
                    }


                    equation.set(i, String.valueOf(res));
                    equation.remove(i-1);
                    equation.remove(i);

                    if (changed)
                        i = 0;
                }
            }
            for (int i = 0; i < equation.size(); i++)
            {
                if (equation.get(i).equals("+")) {
                double firstNum = Double.parseDouble(equation.get(i-1));
                double secondNum = Double.parseDouble(equation.get(i+1));
                double res = firstNum + secondNum;
                equation.set(i, String.valueOf(res));
                equation.remove(i-1);
                equation.remove(i);
            }
            else if (equation.get(i).equals("-")) {
                double firstNum = Double.parseDouble(equation.get(i-1));
                double secondNum = Double.parseDouble(equation.get(i+1));
                double res = firstNum - secondNum;
                equation.set(i, String.valueOf(res));
                equation.remove(i-1);
                equation.remove(i);
            }
            }
        }

        answer = Double.parseDouble(equation.get(0));
        answer = Math.round(answer * 100);
        answer = answer/100;
        return answer;
    }

    public void checkAnswer(double _answer)
    {
        if (_answer == answer)
        {
            correctQuestions++;
        }
        else
            incorrectQuestions++;
        totalQuestions++;

        //Checking whether or not to change difficulty
        if (totalQuestions >= 5 && correctQuestions > 4)
        {
            if (totalQuestions % correctQuestions == 0)
            {
                if (this.diff == Difficulty.EASY)
                    this.diff = Difficulty.MEDIUM;
                else if (this.diff == Difficulty.MEDIUM)
                    this.diff = Difficulty.HARD;
            }
        }
    }




}
