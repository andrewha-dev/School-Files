package a02.aha.ca.aha_b51_a02;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Options extends AppCompatActivity {
    public static final String EMP_DATA = "MyPrefsFile";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
        final RadioButton rdoEasy = (RadioButton) findViewById(R.id.rdoEasy);
        final RadioButton rdoMedium = (RadioButton) findViewById(R.id.rdoMedium);
        final RadioButton rdoHard = (RadioButton) findViewById(R.id.rdoHard);
        final Button btnSave = (Button) findViewById(R.id.btnSaveSettings);
        final CheckBox add = (CheckBox) findViewById(R.id.chkAdd);
        final CheckBox sub = (CheckBox) findViewById(R.id.chkSub);
        final CheckBox mult = (CheckBox) findViewById(R.id.chkMult);
        final CheckBox div = (CheckBox) findViewById(R.id.chkDiv);
        final RadioGroup radioGroup = (RadioGroup) findViewById(R.id.rdoGroup);

        SharedPreferences prefs = getSharedPreferences(EMP_DATA, MODE_PRIVATE);
        String difficulty = prefs.getString("difficulty","none");
        if (difficulty.equals("none"))
            radioGroup.check(R.id.rdoEasy);
        if (difficulty.equals("easy"))
            radioGroup.check(R.id.rdoEasy);
        if (difficulty.equals("medium"))
            radioGroup.check(R.id.rdoMedium);
        if (difficulty.equals("hard"))
            radioGroup.check(R.id.rdoHard);

        boolean addB = prefs.getBoolean("add",false);
        boolean subB = prefs.getBoolean("sub",false);
        boolean multB = prefs.getBoolean("mult",false);
        boolean divB = prefs.getBoolean("div",false);

        if (addB == false)
            add.setChecked(false);
        if (subB == false)
            sub.setChecked(false);
        if (multB == false)
            mult.setChecked(false);
        if (divB == false)
            div.setChecked(false);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String difficulty = "";
                SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
                if (rdoEasy.isChecked())
                    difficulty = "easy";
                if (rdoMedium.isChecked())
                    difficulty = "medium";
                if (rdoHard.isChecked())
                    difficulty = "hard";

                //Afterwards checking the operands they want
                editor.putString("difficulty", difficulty);
                editor.putBoolean("add", add.isChecked());
                editor.putBoolean("sub", sub.isChecked());
                editor.putBoolean("mult", mult.isChecked());
                editor.putBoolean("div", div.isChecked());


                Toast toast = Toast.makeText(Options.this, "Settings Saved", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                toast.show();
                editor.commit();
                finish();
            }
        });
    }


}
