package com.heritage.a1435792.aha_b51_a04;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by 1435792 on 12/8/2017.
 */

public class DatabaseHandler extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "MyTasks.db";
    public static final String TASK_TABLE_NAME = "tasks";
    public static final String TASK_COLUMN_ID = "id";
    public static final String TASK_COLUMN_SEMESTER = "semester";
    public static final String TASK_COLUMN_COURSE = "course";
    public static final String TASK_COLUMN_TYPEOFWORK = "typeOfWork";
    public static final String TASK_COLUMN_TASKNUMBER = "taskNumber";
    public static final String TASK_COLUMN_DUEDATE = "dueDate";
    public static final String TASK_COLUMN_COMMENT = "comment";
    public static final String TASK_COLUMN_STATUS = "status";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "create table " + TASK_TABLE_NAME +
                        " (" + TASK_COLUMN_ID + " integer primary key, " +
                        TASK_COLUMN_SEMESTER + " text, " +
                        TASK_COLUMN_COURSE + " text, " +
                        TASK_COLUMN_TYPEOFWORK + " text, " +
                        TASK_COLUMN_TASKNUMBER + " text, " +
                        TASK_COLUMN_DUEDATE + " text, " +
                        TASK_COLUMN_COMMENT + " text, " +
                        TASK_COLUMN_STATUS + " text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS " + TASK_TABLE_NAME);
        onCreate(db);
    }

    public boolean insertTask  (String semester, String course, String typeOfWork, String taskNumber, String date, String comment, String status)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(TASK_COLUMN_SEMESTER, semester);
        contentValues.put(TASK_COLUMN_COURSE, course);
        contentValues.put(TASK_COLUMN_TYPEOFWORK, typeOfWork);
        contentValues.put(TASK_COLUMN_TASKNUMBER, taskNumber);
        contentValues.put(TASK_COLUMN_DUEDATE, date);
        contentValues.put(TASK_COLUMN_COMMENT, comment);
        contentValues.put(TASK_COLUMN_STATUS, status);

        db.insert(TASK_TABLE_NAME, null, contentValues);
        return true;
    }

    public Task getData(int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from " + TASK_TABLE_NAME + " where id="+id+"", null );
        res.moveToFirst();

        int theId = Integer.parseInt(res.getString(res.getColumnIndex(TASK_COLUMN_ID)));
        String semester = res.getString(res.getColumnIndex(TASK_COLUMN_SEMESTER));;
        String course = res.getString(res.getColumnIndex(TASK_COLUMN_COURSE));
        String typeOfWork = res.getString(res.getColumnIndex(TASK_COLUMN_TYPEOFWORK));
        int taskNumber = Integer.parseInt(res.getString(res.getColumnIndex(TASK_COLUMN_TASKNUMBER)));
        String dueDateString = res.getString(res.getColumnIndex(TASK_COLUMN_DUEDATE));
        DateFormat df = new SimpleDateFormat("EEE, MMM d, yyyy");
        Date dueDateConverted = new Date();
        try {
            dueDateConverted = df.parse(dueDateString);
        } catch (ParseException e) {
            dueDateConverted = new Date();
        }

        String comment = res.getString(res.getColumnIndex(TASK_COLUMN_COMMENT));
        int status = Integer.parseInt(res.getString(res.getColumnIndex(TASK_COLUMN_STATUS)));

        Task task = new Task(theId, semester, course, typeOfWork, taskNumber, dueDateConverted, comment, status);
        return task;
    }

    public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        return (int) DatabaseUtils.queryNumEntries(db, TASK_TABLE_NAME);
    }

    public boolean updateTask (Integer id, String semester, String course, String typeOfWork, String taskNumber, String date, String comment, String status)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(TASK_COLUMN_SEMESTER, semester);
        contentValues.put(TASK_COLUMN_COURSE, course);
        contentValues.put(TASK_COLUMN_TYPEOFWORK, typeOfWork);
        contentValues.put(TASK_COLUMN_TASKNUMBER, taskNumber);
        contentValues.put(TASK_COLUMN_DUEDATE, date);
        contentValues.put(TASK_COLUMN_COMMENT, comment);
        contentValues.put(TASK_COLUMN_STATUS, status);

        db.update(TASK_TABLE_NAME, contentValues, "id = ? ", new String[] { Integer.toString(id) } );
        return true;
    }

    public boolean deleteTask (Integer id)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TASK_TABLE_NAME, "id = ? ", new String[]{Integer.toString(id)});
        return true;
    }


    public ArrayList getAllToDo()
    {
        ArrayList<Task> array_list = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from " + TASK_TABLE_NAME + " where status='0'", null );
        res.moveToFirst();
        while(res.isAfterLast() == false){


            int id = Integer.parseInt(res.getString(res.getColumnIndex(TASK_COLUMN_ID)));
            String semester = res.getString(res.getColumnIndex(TASK_COLUMN_SEMESTER));;
            String course = res.getString(res.getColumnIndex(TASK_COLUMN_COURSE));
            String typeOfWork = res.getString(res.getColumnIndex(TASK_COLUMN_TYPEOFWORK));
            int taskNumber = Integer.parseInt(res.getString(res.getColumnIndex(TASK_COLUMN_TASKNUMBER)));
            String dueDateString = res.getString(res.getColumnIndex(TASK_COLUMN_DUEDATE));
            DateFormat df = new SimpleDateFormat("EEE, MMM d, yyyy");
            Date dueDateConverted = new Date();
            try {
                dueDateConverted = df.parse(dueDateString);
            } catch (ParseException e) {
                dueDateConverted = new Date();
            }

            String comment = res.getString(res.getColumnIndex(TASK_COLUMN_COMMENT));
            int status = Integer.parseInt(res.getString(res.getColumnIndex(TASK_COLUMN_STATUS)));

            Task task = new Task(id, semester, course, typeOfWork, taskNumber, dueDateConverted, comment, status);
            array_list.add(task);
            res.moveToNext();
        }
        return array_list;
    }

    public ArrayList getAllDone()
    {
        ArrayList<Task> array_list = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from " + TASK_TABLE_NAME + " where status='1'", null );
        res.moveToFirst();
        while(res.isAfterLast() == false){


            int id = Integer.parseInt(res.getString(res.getColumnIndex(TASK_COLUMN_ID)));
            String semester = res.getString(res.getColumnIndex(TASK_COLUMN_SEMESTER));;
            String course = res.getString(res.getColumnIndex(TASK_COLUMN_COURSE));
            String typeOfWork = res.getString(res.getColumnIndex(TASK_COLUMN_TYPEOFWORK));
            int taskNumber = Integer.parseInt(res.getString(res.getColumnIndex(TASK_COLUMN_TASKNUMBER)));
            String dueDateString = res.getString(res.getColumnIndex(TASK_COLUMN_DUEDATE));
            DateFormat df = new SimpleDateFormat("EEE, MMM d, yyyy");
            Date dueDateConverted = new Date();
            try {
                dueDateConverted = df.parse(dueDateString);
            } catch (ParseException e) {
                dueDateConverted = new Date();
            }

            String comment = res.getString(res.getColumnIndex(TASK_COLUMN_COMMENT));
            int status = Integer.parseInt(res.getString(res.getColumnIndex(TASK_COLUMN_STATUS)));

            Task task = new Task(id, semester, course, typeOfWork, taskNumber, dueDateConverted, comment, status);
            array_list.add(task);
            res.moveToNext();
        }
        return array_list;
    }

    public ArrayList getAllIDs()
    {
        ArrayList array_list = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from " + TASK_TABLE_NAME, null );
        res.moveToFirst();
        while(res.isAfterLast() == false){
            String id = res.getString(res.getColumnIndex(TASK_COLUMN_ID));
            array_list.add(id);
            res.moveToNext();
        }
        return array_list;
    }

    void deleteAllData()
    {
        SQLiteDatabase sdb= this.getWritableDatabase();
        sdb.delete(TASK_TABLE_NAME, null, null);

    }




}
