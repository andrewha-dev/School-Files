package com.heritage.a1435792.aha_b51_a04;

import android.content.Context;
import android.icu.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Created by 1435792 on 12/8/2017.
 */

public class ToDoList {
    public ArrayList<Task> toDo = new ArrayList<>();

    public void loadList(Context context)
    {
        DatabaseHandler db = new DatabaseHandler(context);
        toDo = db.getAllToDo();
    }

    public void getAllDone(Context context)
    {
        DatabaseHandler db = new DatabaseHandler(context);
        toDo = db.getAllDone();
    }

    public void addToList(Task task, Context context)
    {
        DatabaseHandler db = new DatabaseHandler(context);
        String myFormat = "EEE, MMM d, yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        db.insertTask(task.semester, task.course, task.typeOfWork, String.valueOf(task.taskNumber), sdf.format(task.dueDate), task.comment, "0");
    }

    public ArrayList<String> getAllIds(Context context)
    {
        DatabaseHandler db = new DatabaseHandler(context);
        return db.getAllIDs();
    }


}
