package com.heritage.a1435792.aha_b51_a04;

import android.icu.text.SimpleDateFormat;

import java.util.Date;

/**
 * Created by 1435792 on 12/8/2017.
 */

public class Task {
    public int id;
    public String semester;
    public String course;
    public String typeOfWork;
    public int taskNumber;
    public Date dueDate;
    public String comment;
    public int status;


    public Task()
    {

    }

    public Task(int id, String semester, String course, String typeOfWork, int taskNumber, Date dueDate, String comment, int status) {
        this.id = id;
        this.semester = semester;
        this.course = course;
        this.typeOfWork = typeOfWork;
        this.taskNumber = taskNumber;
        this.dueDate = dueDate;
        this.comment = comment;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getTypeOfWork() {
        return typeOfWork;
    }

    public void setTypeOfWork(String typeOfWork) {
        this.typeOfWork = typeOfWork;
    }

    public int getTaskNumber() {
        return taskNumber;
    }

    public void setTaskNumber(int taskNumber) {
        this.taskNumber = taskNumber;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String display()
    {
        SimpleDateFormat format = new SimpleDateFormat("EEE, MMM d, yyyy");
        return getCourse() + "\n" + getTypeOfWork() + " " + getTaskNumber() + "\n" + format.format(getDueDate())  ;
    }

}
