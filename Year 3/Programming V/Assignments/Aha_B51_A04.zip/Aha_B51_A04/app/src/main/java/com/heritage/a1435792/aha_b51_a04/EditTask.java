package com.heritage.a1435792.aha_b51_a04;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class EditTask extends AppCompatActivity {
    private boolean loading = false;
    int taskID = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_task);

        Button btnCancel = (Button) findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Intent intent = getIntent();
        int id = 0;

        if (null != intent) { //Null Checking

            id = intent.getIntExtra("id", 0);
        }
        DatabaseHandler db = new DatabaseHandler(getApplicationContext());
        //System.out.println(id);
        //db.deleteAllData();
        Task task = db.getData(id);
        taskID = id;

        display(task);








        final Calendar myCalendar = Calendar.getInstance();
        final EditText edittext= (EditText) findViewById(R.id.txtDate);
        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "EEE, MMM d, yyyy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                edittext.setText(sdf.format(myCalendar.getTime()));
            }

        };

        edittext.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(EditTask.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        Spinner spinner = (Spinner)findViewById(R.id.ddlSem);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (loading != true)
                {
                    Spinner spinner = (Spinner)findViewById(R.id.ddlClass);
                    ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(view.getContext(), android.R.layout.simple_spinner_item, android.R.id.text1);
                    String[] array = new String[0];

                    switch(position)
                    {
                        case 0:
                            array = getResources().getStringArray(R.array.classSem1);
                            break;
                        case 1:
                            array = getResources().getStringArray(R.array.classSem2);
                            break;
                        case 2:
                            array = getResources().getStringArray(R.array.classSem3);
                            break;
                        case 3:
                            array = getResources().getStringArray(R.array.classSem4);
                            break;
                        case 4:
                            array = getResources().getStringArray(R.array.classSem5);
                            break;
                        case 5:
                            array = getResources().getStringArray(R.array.classSem6);
                            break;
                        default:
                            break;
                    }
                    //spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    spinnerAdapter = new ArrayAdapter<String>(view.getContext(), android.R.layout.simple_spinner_item, array);
                    spinner.setAdapter(spinnerAdapter);
                    spinnerAdapter.notifyDataSetChanged();
                }
                else
                    loading = false;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Button btnUpdate = (Button) findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner semester = (Spinner) findViewById(R.id.ddlSem);
                Spinner course = (Spinner) findViewById(R.id.ddlClass);
                Spinner typeOfWork = (Spinner) findViewById(R.id.ddlTaskType);
                Spinner number = (Spinner) findViewById(R.id.ddlTaskNum);
                EditText date = (EditText) findViewById(R.id.txtDate);
                EditText comment = (EditText) findViewById(R.id.txtComment);

                String seme = semester.getSelectedItem().toString();
                String cour = course.getSelectedItem().toString();
                String tow = typeOfWork.getSelectedItem().toString();
                int num = number.getSelectedItemPosition() + 1;
                DateFormat df = new SimpleDateFormat("EEE, MMM d, yyyy");
                Date dueDateConverted = new Date();
                try {
                    dueDateConverted = df.parse(date.getText().toString());
                } catch (ParseException e) {
                    dueDateConverted = new Date();
                }

                String comm = comment.getText().toString();

                CheckBox status = (CheckBox) findViewById(R.id.chkStatus);
                int taskStatus = 0;
                if (status.isChecked())
                taskStatus = 1;
                Task task = new Task(0, seme, cour, tow, num, dueDateConverted, comm, taskStatus);
                DatabaseHandler db = new DatabaseHandler(getApplicationContext());
                String myFormat = "EEE, MMM d, yyyy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                db.updateTask(taskID, task.semester, task.course, task.typeOfWork, String.valueOf(task.taskNumber) ,sdf.format(task.getDueDate()) , task.comment, String.valueOf(task.status));
                Toast.makeText(getApplicationContext(), "Task Updated!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        Button btnDelete = (Button) findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatabaseHandler db = new DatabaseHandler(getApplicationContext());

                db.deleteTask(taskID);
                Toast.makeText(getApplicationContext(), "Task Deleted!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    public void display(Task task)
    {
        loading = true;
        Spinner semester = (Spinner) findViewById(R.id.ddlSem);


        Spinner number = (Spinner) findViewById(R.id.ddlTaskNum);
        number.setSelection(task.getTaskNumber() - 1);

        EditText date = (EditText) findViewById(R.id.txtDate);
        EditText comment = (EditText) findViewById(R.id.txtComment);
        Resources res = getResources();

        System.out.println(task.semester);
        System.out.println(task.display());
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.semester, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        semester.setAdapter(adapter);
        if (!task.getSemester().equals(null)) {
            int spinnerPosition = adapter.getPosition(task.getSemester());
            semester.setSelection(spinnerPosition);
        }

        switch (task.semester)
        {
            case "Semester 1":
                adapter = ArrayAdapter.createFromResource(this, R.array.classSem1, android.R.layout.simple_spinner_item);
                break;
            case "Semester 2":
                adapter = ArrayAdapter.createFromResource(this, R.array.classSem2, android.R.layout.simple_spinner_item);
                break;
            case "Semester 3":
                adapter = ArrayAdapter.createFromResource(this, R.array.classSem3, android.R.layout.simple_spinner_item);
                break;
            case "Semester 4":
                adapter = ArrayAdapter.createFromResource(this, R.array.classSem4, android.R.layout.simple_spinner_item);
                break;
            case "Semester 5":
                adapter = ArrayAdapter.createFromResource(this, R.array.classSem5, android.R.layout.simple_spinner_item);
                break;
            case "Semester 6":
                adapter = ArrayAdapter.createFromResource(this, R.array.classSem6, android.R.layout.simple_spinner_item);
                break;
            default:
                break;
        }
        Spinner course = (Spinner) findViewById(R.id.ddlClass);

        ArrayAdapter<CharSequence> adapterClass = null;
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        switch (task.semester)
        {
            case "Semester 1":
                adapterClass = ArrayAdapter.createFromResource(this, R.array.classSem1, android.R.layout.simple_spinner_item);
                break;
            case "Semester 2":
                adapterClass = ArrayAdapter.createFromResource(this, R.array.classSem2, android.R.layout.simple_spinner_item);
                break;
            case "Semester 3":
                adapterClass = ArrayAdapter.createFromResource(this, R.array.classSem3, android.R.layout.simple_spinner_item);
                break;
            case "Semester 4":
                adapterClass = ArrayAdapter.createFromResource(this, R.array.classSem4, android.R.layout.simple_spinner_item);
                break;
            case "Semester 5":
                adapterClass = ArrayAdapter.createFromResource(this, R.array.classSem5, android.R.layout.simple_spinner_item);
                break;
            case "Semester 6":
                adapterClass = ArrayAdapter.createFromResource(this, R.array.classSem6, android.R.layout.simple_spinner_item);
                break;
            default:
                break;
        }
        course.setAdapter(adapterClass);
        if (!task.getSemester().equals(null)) {
            int spinnerPosition = adapterClass.getPosition(task.getCourse());
            course.setSelection(spinnerPosition);
        }

        Spinner typeOfWork = (Spinner) findViewById(R.id.ddlTaskType);
        ArrayAdapter<CharSequence> adapterType = ArrayAdapter.createFromResource(this, R.array.taskType, android.R.layout.simple_spinner_item);
        adapterType.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeOfWork.setAdapter(adapterType);
        if (!task.typeOfWork.equals(null)) {
            int spinnerPosition = adapterType.getPosition(task.getTypeOfWork());
            typeOfWork.setSelection(spinnerPosition);
        }

        String myFormat = "EEE, MMM d, yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        date.setText(sdf.format(task.dueDate));


        //semester.setSelected(.);
        //course.getSelectedItem().toString();
        //typeOfWork.getSelectedItem().toString();
        //number.getSelectedItemPosition() + 1;

        comment.setText(task.getComment());
        CheckBox status = (CheckBox) findViewById(R.id.chkStatus);
        if (task.status == 1)
        {
            status.setChecked(true);
        }

    }

}
