package com.heritage.a1435792.aha_b51_a04;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class Settings extends AppCompatActivity {
    static final String EMP_DATA = "MyPrefs";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Spinner spinner = (Spinner)findViewById(R.id.ddlCurrSem);

        int currSemester = 0;
        SharedPreferences prefs = getSharedPreferences(EMP_DATA, MODE_PRIVATE);

        // Read the Shared Preferences vales
        currSemester = prefs.getInt("currSemester",1);

        spinner.setSelection(currSemester);

        Button btnCancel = (Button) findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Button btnSave = (Button) findViewById(R.id.btnSaveSettings);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
                Spinner ddlSemester = (Spinner) findViewById(R.id.ddlCurrSem);
                // Write the shared preferences values and commit them
                editor.putInt("currSemester",ddlSemester.getSelectedItemPosition());
                editor.commit();
                finish();

            }
        });

    }

}
