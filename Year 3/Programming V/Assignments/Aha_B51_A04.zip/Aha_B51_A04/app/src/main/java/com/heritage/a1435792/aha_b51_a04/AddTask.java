package com.heritage.a1435792.aha_b51_a04;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class AddTask extends AppCompatActivity {
    static final String EMP_DATA = "MyPrefs";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);
        final Calendar myCalendar = Calendar.getInstance();
        final EditText edittext= (EditText) findViewById(R.id.txtDate);
        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "EEE, MMM d, yyyy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                edittext.setText(sdf.format(myCalendar.getTime()));
            }

        };

        edittext.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(AddTask.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        Spinner spinner = (Spinner)findViewById(R.id.ddlSem);

        int currSemester = 0;
        SharedPreferences prefs = getSharedPreferences(EMP_DATA, MODE_PRIVATE);

        // Read the Shared Preferences vales
        currSemester = prefs.getInt("currSemester",1);

        spinner.setSelection(currSemester);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Spinner spinner = (Spinner)findViewById(R.id.ddlClass);
                ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, android.R.id.text1);
                String[] array = new String[0];

                switch(position)
                {
                    case 0:
                        array = getResources().getStringArray(R.array.classSem1);
                        break;
                    case 1:
                        array = getResources().getStringArray(R.array.classSem2);
                        break;
                    case 2:
                        array = getResources().getStringArray(R.array.classSem3);
                        break;
                    case 3:
                        array = getResources().getStringArray(R.array.classSem4);
                        break;
                    case 4:
                        array = getResources().getStringArray(R.array.classSem5);
                        break;
                    case 5:
                        array = getResources().getStringArray(R.array.classSem6);
                        break;
                    default:
                        break;
                }
                //spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, array);
                spinner.setAdapter(spinnerAdapter);
                spinnerAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Button btnCancel = (Button) findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Button btnAdd = (Button) findViewById(R.id.btnAddTask);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner semester = (Spinner) findViewById(R.id.ddlSem);
                Spinner course = (Spinner) findViewById(R.id.ddlClass);
                Spinner typeOfWork = (Spinner) findViewById(R.id.ddlTaskType);
                Spinner number = (Spinner) findViewById(R.id.ddlTaskNum);
                EditText date = (EditText) findViewById(R.id.txtDate);
                EditText comment = (EditText) findViewById(R.id.txtComment);

                String seme = semester.getSelectedItem().toString();
                String cour = course.getSelectedItem().toString();
                String tow = typeOfWork.getSelectedItem().toString();
                int num = number.getSelectedItemPosition() + 1;
                DateFormat df = new SimpleDateFormat("EEE, MMM d, yyyy");
                Date dueDateConverted = new Date();
                try {
                    dueDateConverted = df.parse(date.getText().toString());
                } catch (ParseException e) {
                    dueDateConverted = new Date();
                }

                String comm = comment.getText().toString();
                Task task = new Task(0, seme, cour, tow, num, dueDateConverted, comm, 0);

                ToDoList td = new ToDoList();
                td.addToList(task, getApplicationContext());
                Toast.makeText(getApplicationContext(), "Task Added!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });


    }
}
