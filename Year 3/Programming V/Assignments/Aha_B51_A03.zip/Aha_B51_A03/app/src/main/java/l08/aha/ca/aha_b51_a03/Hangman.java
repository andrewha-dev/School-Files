package l08.aha.ca.aha_b51_a03;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static android.R.id.list;
import static android.content.Context.MODE_PRIVATE;
import static java.lang.System.out;

/**
 * Created by 1435792 on 11/17/2017.
 */

public class Hangman {
    public String currentWord = "";
    public String currentWordGuessedDisplay = "";
    public int minLength = 3;
    public int maxLength = 100;
    public int chances = 6;
    public ArrayList<String> wordsForGame = new ArrayList<>();
    public ArrayList<String> guessedLetters = new ArrayList<>();
    public boolean guessed = false;

    public int difficulty = 0;
    public String guessedLettersDisplay = "";


    public Hangman()
    {

    }

    public Hangman(int _minLength, int _maxLength, int _difficulty)
    {
        chances = 6;
        minLength = _minLength;
        maxLength = _maxLength;
        difficulty = _difficulty;
    }

    public void setWords(ArrayList<String> words)
    {
        //Processing words based off of the difficulty
        for(int i = 0; i < words.size(); i++)
        {
            if (words.get(i).length() >= minLength && words.get(i).length() <= maxLength)
            {
                System.out.println(words.get(i));
                wordsForGame.add(words.get(i));
            }
        }
    }

    public void chooseWord()
    {
        Random randomizer = new Random();
        int index = randomizer.nextInt(wordsForGame.size());
        currentWord = wordsForGame.get(index);
        //remove word from the list
        wordsForGame.remove(index);
        //Creating the blanks
        for(int i = 0; i < currentWord.length(); i++)
        {
            currentWordGuessedDisplay += "__ ";
        }
        System.out.println(currentWord);
    }

    public void checkLetter(String letter)
    {
        //Add the letter to the list first
        guessedLetters.add(letter);

        //Resetting the current word guess display
        boolean found = false;
        //Checking to see if the letter is in the word

        //First going to copy it over to a string array, and then add the values
        //Our string has an extra space at the end so we'll remove that first
        String tempCurrentWord = currentWordGuessedDisplay.trim();
        ArrayList<String> arrCurrWord = new ArrayList<String>( Arrays.asList(tempCurrentWord.split(" ")));
        for(int i = 0; i < arrCurrWord.size(); i++)
        {
            if (String.valueOf(currentWord.charAt(i)).equals(letter))
            {
                arrCurrWord.set(i, letter);
                found = true;
            }
        }

        if (found == false)
        {
            chances--;
        }
        currentWordGuessedDisplay = "";
        for(int i = 0; i < arrCurrWord.size(); i++)
        {
            currentWordGuessedDisplay += arrCurrWord.get(i) + " ";
        }




        guessedLettersDisplay = "";
        //Updating the guessed letters
        for (int i = 0; i < guessedLetters.size(); i++)
        {
            guessedLettersDisplay += " " + guessedLetters.get(i);

        }
    }








}
