package l08.aha.ca.aha_b51_a03;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import static java.lang.System.out;

public class Game extends AppCompatActivity {
    String EMP_DATA = "MyPrefs";
    Hangman hangman = new Hangman();
    public String FILE_NAME = "";
    AssetManager assetManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        assetManager = getAssets();

        SharedPreferences prefs = getSharedPreferences(EMP_DATA, MODE_PRIVATE);

        // Read the Shared Preferences vales
        int min = prefs.getInt("min", 3);
        int max = prefs.getInt("max", 100);
        int difficulty = prefs.getInt("difficulty", 0);

        hangman.maxLength = prefs.getInt("max", 100);
        hangman.difficulty = prefs.getInt("difficulty", 0);
        hangman.currentWord = prefs.getString("currentWord", "Error");
        hangman.chances = prefs.getInt("chances", 6);
        hangman.currentWordGuessedDisplay = prefs.getString("currentWordDisplay", "Error");
        hangman.guessedLettersDisplay = prefs.getString("guessedLetters", "Error");


        if (hangman.currentWord.equals("Error"))
        {
            hangman = new Hangman(min, max, difficulty);
            loadFiles();
        }


        updateDisplay();

        Button btnSubmit = (Button) findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText txtLetter = (EditText)findViewById(R.id.txtLetter);



                String submittedLetter = txtLetter.getText().toString();
                if (!submittedLetter.equals(""))
                {
                    //Compares to see if the letter is already guessed
                    if (!hangman.guessedLetters.contains(submittedLetter))
                    {
                        hangman.checkLetter(submittedLetter);
                        updateDisplay();
                    }
                    else {
                        Context context = getApplicationContext();
                        Toast.makeText(context, "The letter " + "'" + submittedLetter + "'" + " has already been guessed " ,Toast.LENGTH_SHORT).show();
                    }
                    //Clear the input after
                    txtLetter.setText("");
                }

            }
        });

    }

    public void loadFiles()
    {
        ArrayList<String> words = new ArrayList<>();
        if (hangman.difficulty == 0)
        {
            FILE_NAME = "hangwords_easy.txt";

        }
        else
        {
            FILE_NAME = "hangwords_hard.txt";
        }

        try {
            InputStream inputStream = assetManager.open(FILE_NAME);
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String mLine, newmLine;
            while ((mLine = bufferedReader.readLine()) != null) {
                newmLine =  mLine;
                words.add(newmLine);
            }
            hangman.setWords(words);
            if (hangman.wordsForGame.size() != 0)
            hangman.chooseWord();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void updateDisplay()
    {
        TextView chances = (TextView) findViewById(R.id.lblChancesValue);
        chances.setText(String.valueOf(hangman.chances));
        TextView wordDisplay = (TextView) findViewById(R.id.lblWord);
        wordDisplay.setText(hangman.currentWordGuessedDisplay);
        TextView guessedLetters = (TextView) findViewById(R.id.lblGuessedLettersValue);
        guessedLetters.setText(hangman.guessedLettersDisplay);

        if (hangman.chances <= 0 && hangman.currentWordGuessedDisplay.contains("__"))
        {
            AlertDialog.Builder dialog = new AlertDialog.Builder(Game.this);
            dialog.setCancelable(false);
            dialog.setTitle("Game over!");
            dialog.setMessage("You have run out of guesses. The word was '" + hangman.currentWord + "' Would you like to return to the main menu or exit the app?" );
            dialog.setPositiveButton("Exit Application", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                    SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
                    editor.putString("currentWord", "Error");
                    editor.commit();
                    Intent intent = new Intent(Intent.ACTION_MAIN);
                    intent.addCategory(Intent.CATEGORY_HOME);
                    startActivity(intent);
                    int pid = android.os.Process.myPid();
                    android.os.Process.killProcess(pid);
                }
            }).setNegativeButton("Exit To Main Menu", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
                            editor.putString("currentWord", "Error");
                            editor.commit();
                    finish();
                        }
                    });
            SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
            editor.putString("currentWord", "Error");
            editor.commit();
            final AlertDialog alert = dialog.create();
            alert.show();
        }

        if (!hangman.currentWordGuessedDisplay.contains("_"))
        {
            AlertDialog.Builder dialog = new AlertDialog.Builder(Game.this);
            dialog.setCancelable(false);
            dialog.setTitle("Congratulations!");
            dialog.setMessage("You have successfully guessed the word!. Would you like to return to the main menu or exit the app?" );
            dialog.setPositiveButton("Exit Application", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                    Intent intent = new Intent(Intent.ACTION_MAIN);
                    intent.addCategory(Intent.CATEGORY_HOME);
                    startActivity(intent);
                    int pid = android.os.Process.myPid();
                    android.os.Process.killProcess(pid);
                    SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
                    editor.putString("currentWord", "Error");
                    editor.commit();
                }
            }).setNegativeButton("Exit To Main Menu", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
                    editor.putString("currentWord", "Error");
                    editor.commit();
                    finish();
                }
            });
            SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
            editor.putString("currentWord", "Error");
            editor.commit();
            hangman.guessed = true;
            final AlertDialog alert = dialog.create();
            alert.show();
        }
    }

    public void UpdateDisplayNoCheck()
    {
        TextView chances = (TextView) findViewById(R.id.lblChancesValue);
        chances.setText(String.valueOf(hangman.chances));
        TextView wordDisplay = (TextView) findViewById(R.id.lblWord);
        wordDisplay.setText(hangman.currentWordGuessedDisplay);
        TextView guessedLetters = (TextView) findViewById(R.id.lblGuessedLettersValue);
        guessedLetters.setText(hangman.guessedLettersDisplay);
    }

    @Override
    public void onStart() {
        super.onStart();
        SharedPreferences prefs = getSharedPreferences(EMP_DATA, MODE_PRIVATE);

            UpdateDisplayNoCheck();

    }

    @Override
    public void onResume() {
        super.onResume();
        SharedPreferences prefs = getSharedPreferences(EMP_DATA, MODE_PRIVATE);
        UpdateDisplayNoCheck();

    }

    @Override
    public void onPause() {
        super.onPause();
        SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
        if (hangman.guessed == true)
        {
            editor.putString("currentWordDisplay", "Error");
            hangman.chances = -1;
        }
        if (hangman.chances > 0)
        {

            editor.putString("currentWord", hangman.currentWord);

        }
        else
        {
            editor.putString("currentWord", "Error");
        }
        editor.putInt("chances", hangman.chances);
        editor.putInt("difficulty", hangman.difficulty);
        editor.putInt("min", hangman.minLength);
        editor.putInt("max", hangman.maxLength);
        editor.putString("currentWordDisplay", hangman.currentWordGuessedDisplay);
        editor.putString("guessedLetters", hangman.guessedLettersDisplay);
        editor.commit();

    }

    @Override
    public void onStop() {
        super.onStop();
        SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
        if (hangman.guessed == true)
        {
            editor.putString("currentWordDisplay", "Error");
            hangman.chances = -1;
        }
        if (hangman.chances > 0)
        {

            editor.putString("currentWord", hangman.currentWord);

        }
        else
        {
            editor.putString("currentWord", "Error");
        }
        editor.putInt("chances", hangman.chances);
        editor.putInt("difficulty", hangman.difficulty);
        editor.putInt("min", hangman.minLength);
        editor.putInt("max", hangman.maxLength);
        editor.putString("currentWordDisplay", hangman.currentWordGuessedDisplay);
        editor.putString("guessedLetters", hangman.guessedLettersDisplay);

        editor.commit();
    }
}
