package l08.aha.ca.aha_b51_a03;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class Options extends AppCompatActivity {
    EditText min;
    EditText max;
    String EMP_DATA = "MyPrefs";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);
        min = (EditText) findViewById(R.id.txtMin);

        max = (EditText) findViewById(R.id.txtMax);
        Button btnSaveSettings = (Button) findViewById(R.id.btnSaveSettings);

        min.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus)
                {
                    if (!min.getText().toString().equals(""))
                    {
                        if (Integer.parseInt(min.getText().toString()) < 3)
                        {
                            min.setText("3");
                        }
                    }
                }
            }
        });

        SharedPreferences prefs = getSharedPreferences(EMP_DATA, MODE_PRIVATE);

        // Read the Shared Preferences vales
        int minVal = prefs.getInt("min", 3);
        int maxVal = prefs.getInt("max", 100);
        int difficultyVal = prefs.getInt("difficulty", 0);
        RadioGroup rg = (RadioGroup) findViewById(R.id.rdoGroup);
        min.setText(String.valueOf(minVal));
        max.setText(String.valueOf(maxVal));
        if (difficultyVal == 0)
        {
            RadioButton rdEasy = (RadioButton) findViewById(R.id.rdoEasy);
            rdEasy.setChecked(true);
        }

        if (difficultyVal == 1)
        {
            RadioButton rdHard = (RadioButton) findViewById(R.id.rdoHard);
            rdHard.setChecked(true);
        }


        btnSaveSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!min.getText().toString().equals("") && !max.getText().toString().equals(""))
                {
                    SharedPreferences.Editor editor = getSharedPreferences(EMP_DATA,MODE_PRIVATE).edit();
                    if (Integer.parseInt(min.getText().toString()) < 3)
                    {
                        editor.putInt("min", 3);
                    }
                    else
                    {
                        editor.putInt("min", Integer.parseInt(min.getText().toString()));
                    }
                    editor.putInt("max", Integer.parseInt(max.getText().toString()));
                    RadioGroup rg = (RadioGroup) findViewById(R.id.rdoGroup);
                    int difficulty = 0;
                    int id = rg.getCheckedRadioButtonId();
                    if (id == R.id.rdoEasy)
                    {
                        difficulty = 0;
                    }

                    if (id == R.id.rdoHard)
                    {
                        difficulty = 1;
                    }

                    editor.putInt("difficulty", difficulty);
                    editor.commit();
                    finish();

                }
            }
        });
    }
}
