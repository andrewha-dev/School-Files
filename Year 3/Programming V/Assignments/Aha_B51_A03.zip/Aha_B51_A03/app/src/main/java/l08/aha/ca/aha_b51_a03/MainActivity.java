package l08.aha.ca.aha_b51_a03;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnPlay = (Button) findViewById(R.id.btnPlay);
        Button btnOption = (Button) findViewById(R.id.btnOption);
        Button btnAbout = (Button) findViewById(R.id.btnAbout);

        btnPlay.setOnClickListener(listener);
        btnOption.setOnClickListener(listener);
        btnAbout.setOnClickListener(listener);
    }


    View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i;
            switch (v.getId())
            {
                case R.id.btnPlay:
                    i = new Intent(MainActivity.this, Game.class);
                    startActivity(i);
                    break;
                case R.id.btnOption:
                    i = new Intent(MainActivity.this, Options.class);
                    startActivity(i);
                    break;
                case R.id.btnAbout:
                    i = new Intent(MainActivity.this, About.class);
                    startActivity(i);
                    break;
                default:
                    break;
            }
        }
    };
}
