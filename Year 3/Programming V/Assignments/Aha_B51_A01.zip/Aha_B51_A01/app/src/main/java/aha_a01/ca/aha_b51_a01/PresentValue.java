package aha_a01.ca.aha_b51_a01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class PresentValue extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_present_value);
        Bundle extra = getIntent().getExtras();
        String typeCalc = "";
        double interestRate = 0.0;
        int years = 0;
        int freq = 0;
        double amount = 0.0;

        final TextView lblInputAmt = (TextView) findViewById(R.id.lblPresentAmt);
        if (extra != null)
        {
            String res = "Future Value Wanted: ";
            interestRate = extra.getDouble("interestRate");

            years = extra.getInt("years");
            freq = extra.getInt("freq");
            amount = extra.getDouble("amount");
            res +=  "$" + (String.format("%,.2f", amount));
            lblInputAmt.setText(res);
            displayResult(amount, interestRate, years, freq);
        }
    }
    private void displayResult(double _amount, double _rate, int _years, int _freq)
    {
        double amount = _amount;
        TableLayout tblRes = (TableLayout) findViewById(R.id.tblRes);
        for (int i = 1; i <= _years; i++)
        {
            TableRow entry = new TableRow(this);
            TableLayout entryLayout = new TableLayout(this);


            TextView lblYear = new TextView(this);
            String year = String.valueOf(i+ "   ");
            lblYear.setText(year);


            TextView lblInterestCell = new TextView(this);
            String interest = String.valueOf(i + 1);


            TextView lblTotal = new TextView(this);
            String total = String.valueOf(i + 1);
            double amountBefore = amount;
            amount = (calcInterest(amount, _rate, i, _freq));
            lblTotal.setText( "$"  + (String.format("%,.2f", amount)));

            lblInterestCell.setText( "$" + (String.format("%,.2f", (amount - amountBefore))));

            entry.addView(lblYear);

            entry.addView(lblTotal);

            entry.addView(entryLayout);
            tblRes.addView(entry);


        }
        for (int i = 1; i <=3; i++)
        {
            TableRow entry = new TableRow(this);
            TableLayout entryLayout = new TableLayout(this);


            TextView lblYear = new TextView(this);
            lblYear.setText(" ");


            TextView lblInterestCell = new TextView(this);


            TextView lblTotal = new TextView(this);
            lblTotal.setText(" ");

            lblInterestCell.setText(" ");

            entry.addView(lblYear);
            entry.addView(lblInterestCell);
            entry.addView(lblTotal);

            entry.addView(entryLayout);
            tblRes.addView(entry);
        }


    }

    private double calcInterest(double _amount, double _rate, int _years, int _freq) {
        double res = 0.0;
        int year = _years;
//        if (_years == 0)
//            year = 1;
        double theRate = 1 + (_rate / 100.00);
        res = (_amount) / Math.pow( (1 + (_rate / 100.00)), ( 1.0 /_freq));
        return res;
    }
}
