package aha_a01.ca.aha_b51_a01;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.renderscript.ScriptGroup;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;

public class InputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);
        //Activity Variables
        final Button btnCalc = (Button) findViewById(R.id.btnCalc);
        final Spinner ddlTypeCalc = (Spinner) findViewById(R.id.ddlTypeCalc);
        final Spinner ddlFreq = (Spinner) findViewById(R.id.ddlFrequency);
        final SeekBar sbYears = (SeekBar) findViewById(R.id.sbYear);
        final SeekBar sbRate = (SeekBar) findViewById(R.id.sbRate);
        final TextView lblYearRes =  (TextView) findViewById(R.id.lblYearRes);
        final TextView lblRateRes =  (TextView) findViewById(R.id.lblRateRes);
        final EditText txtAmount = (EditText) findViewById(R.id.txtValue);
        //Setting the maximum seekbars
        sbYears.setProgress(1);
        sbRate.setProgress(5);
        sbYears.setMax(50);


        //Disable the calculate button on first create
        btnCalc.setEnabled(false);

        txtAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if ((!ddlFreq.getSelectedItem().toString().equals("Please Select a Frequency")) && (!ddlTypeCalc.getSelectedItem().toString().equals("Please Select a Value"))
                        && (!txtAmount.getText().toString().equals("") && !txtAmount.getText().toString().equals(".")))
                {
                    btnCalc.setEnabled(true);
                }
                else
                    btnCalc.setEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        ddlTypeCalc.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String typeCalc = ddlTypeCalc.getSelectedItem().toString();
                if ((!ddlFreq.getSelectedItem().toString().equals("Please Select a Frequency")) && (!ddlTypeCalc.getSelectedItem().toString().equals("Please Select a Value"))
                        && (!txtAmount.getText().toString().equals("") && !txtAmount.getText().toString().equals(".")))
                {
                    btnCalc.setEnabled(true);
                }
                else
                    btnCalc.setEnabled(false);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                btnCalc.setEnabled(false);
            }


        });

        ddlFreq.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String typeCalc = ddlFreq.getSelectedItem().toString();
                if ((!ddlFreq.getSelectedItem().toString().equals("Please Select a Frequency")) && (!ddlTypeCalc.getSelectedItem().toString().equals("Please Select a Value"))
                        && (!txtAmount.getText().toString().equals("") && !txtAmount.getText().toString().equals(".")))
                {
                    btnCalc.setEnabled(true);
                }
                else
                    btnCalc.setEnabled(false);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        sbRate.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int theProgress = sbRate.getProgress();
                if (theProgress >= 5 && theProgress <= 100)
                {
                    lblRateRes.setText(String.valueOf((theProgress/10.0)) + "  %");
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (sbRate.getProgress() <= 5){
                    sbRate.setProgress(5);
                }
            }
        });


        sbYears.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int theProgress = sbYears.getProgress();
                if (theProgress >= 1 && theProgress <= 50)
                {
                    lblYearRes.setText(theProgress + "  years");
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                int theProgress = sbYears.getProgress();
                if (theProgress < 1)
                    sbYears.setProgress(1);

            }
        });

        btnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String typeCalc = ddlTypeCalc.getSelectedItem().toString();
                double interestRate = sbRate.getProgress() / 10.0;
                int years = sbYears.getProgress();
                String frequency = ddlFreq.getSelectedItem().toString();
                int freqInt = freqToNum(frequency);
                double amount = Double.parseDouble(txtAmount.getText().toString());


                //Opening the activity based off of the type
                if (typeCalc.equals("Present Value"))
                {
                    presentValue();
                    Intent i = new Intent(InputActivity.this, PresentValue.class);
                    i.putExtra("typeCalc", typeCalc);
                    i.putExtra("interestRate", interestRate);
                    i.putExtra("years", years);
                    i.putExtra("freq", freqInt);
                    i.putExtra("amount", amount);
                    startActivity(i);
                }
                else
                {
                    futureValue();
                    Intent j = new Intent(InputActivity.this, FutureValue.class);
                    j.putExtra("typeCalc", typeCalc);
                    j.putExtra("interestRate", interestRate);
                    j.putExtra("years", years);
                    j.putExtra("freq", freqInt);
                    j.putExtra("amount", amount);
                    startActivity(j);
                }

            }
        });

    }

    public void presentValue() {
        Context context = getApplicationContext();
        CharSequence text = "Calculated Present Value";
        int duration = Toast.LENGTH_SHORT;

        final Toast toast = Toast.makeText(context, text, duration);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                toast.show();
            }
        }, 750);
    }

    public void futureValue()
    {
        Context context = getApplicationContext();
        CharSequence text = "Calculated Future Value";
        int duration = Toast.LENGTH_SHORT;

        final Toast toast = Toast.makeText(context, text, duration);

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                toast.show();
            }
        }, 750);

    }

    public int freqToNum(String _freq)
    {
        int freq = 0;
        switch (_freq)
        {
            case "Monthly":
                freq = 12;
                break;
            case "Quarterly":
                freq = 4;
                break;
            case "Semi-Annually":
                freq = 2;
                break;
            case "Annually":
                freq = 1;
                break;
            default:
                freq = 0;
                break;
        }
        return freq;
    }




}
